<?php

	/********************************************************************
	*	navbar.php - Author: Danish Zahur								*
	*	This file is a part of MyWebSQL package							*
	*	Contains GUI navigation bar class								*
	*	PHP5 compatible													*
	*********************************************************************/

if (defined("CLASS_NAVBAR_INCLUDED"))
	return true;

define("CLASS_NAVBAR_INCLUDED", "1");

class NavigationBar
{
	var $imgPath;
	var $buttons;
	var $resetCode;
	var $showText;		// if false, will show as tooltip
	
	function __construct()
	{
		$this->NavigationBar();
	}
	
	function NavigationBar()
	{
		$this->imgPath  = "/images/";
		$this->resetCode = 0;
		$this->showText = true;
		$this->buttons = array();
	}
	
	function setImgPath($path)
	{
		$this->imgPath  = $path;
		if (substr($path, -1, 1) != "/")
			$this->imgPath .= "/";
	}
	
	function showText($bool)
	{
		$this->showText = $bool;
	}
	
	function reset()
	{
		$this->buttons = array();
		$this->resetCode = 1;
	}

	function addButton($link, $text="", $img="", $id="")
	{
		$bn = array($link, $text, $img, $id);
		$this->buttons[] = $bn;
	}
	
	// do not call this method unless absolutely necessary ... use getCode() for ajax applications
	function getHtml()
	{
		$div = "<div style='padding-top:2px;padding-left:4px'>";	//<div id='navbarmsg' style='float:left'></div>";
		foreach($this->buttons as $bn)
		{
			$div .= "<div id='nav_$bn[3]' class='navBtnBg' onmouseover=\"this.className='navBtnHv';\" onmouseout=\"this.className='navBtnBg';\"";
			
			if(!$this->showText)		// show tooltip
				$div .= " title=\"".htmlspecialchars($bn[1])."\"";
			
			$div .= "><A class='navBtn' href=\"$bn[0]\">";
			if ($bn[2] != "")
				$div .= "<img border=\"0\" align=\"middle\" width=\"16\" height=\"16\" src='$this->imgPath". "$bn[2]' alt=\"\" style=\"margin-right:5px\" />";
			if ($this->showText)
				$div .= "$bn[1]";
				//$div .= "<span class='navSpc'>$bn[1]</span>";
			$div .= "</a></div>";
		}
		$div .= "</div>";
		
		return $div;
	}
	
	function getCode()
	{
		$code = "";
		if ($this->resetCode)
			$code = "document.getElementById('navbar').innerHTML = '';\n";
		
		$code .= "document.getElementById('navbar').innerHTML += \"". str_replace("\"", "\\\"", $this->getHtml()) ."\";";
		
		return $code;
	}
}

?>
