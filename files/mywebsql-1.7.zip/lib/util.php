<?php

	/***************************************************************
	*  util.php - Author: Samnan ur Rehman                         *
	*  This file is a part of MyWebSQL package                     *
	*  Core functions for server side mysql related functionality  *
	*  PHP5 compatible                                             *
	***************************************************************/

	include('functions.php');

	function view($name, $replace = array())
	{
		$find = array();
		foreach($replace as $key => $value)
			$find[] = '{{' . $key . '}}';
		$replace = array_values($replace);
		$file = file_get_contents(BASE_PATH . '/modules/views/' . $name . '.php');
		return str_replace($find, $replace, $file);
	}

	function showDBError()
	{
		return "Database connection failed to the server. Host: ".DB_HOST.", User: ".DB_USER;
	}

	function getDbName()
	{
		return Session::get('db', 'name');
	}

	function printDbList(&$db, &$HTML)
	{
		global $DB_CONFIG;
		$dblist = Session::get('db', 'list') ? array(Session::get('db', 'name')) : $db->getDatabases();

		// if there is one database for the given userid, lets select it to cut out one extra step
		if (! Session::get('db', 'name') )
		{
			$stDb = 0; $selDb = "";
			foreach($dblist as $dbname)
			{
				if ($dbname == "information_schema" || $dbname == "performance_schema" || $dbname == "mysql" || $dbname == "test")
					$stDb++;
				else
					$selDb = $dbname;
			}
			if (count($dblist) == ($stDb+1))
			{
				Session::set('db', 'name', $selDb);
				$db->selectDb(Session::get('db', 'name'));
			}
		}
		// --- end of automatic selection logic

		if (getDbName())
		{
			$HTML->select("dblist", "id='dblist' onchange='dbSelect()'", "", "width:100%");
			foreach($dblist as $dbname)
				$HTML->option($dbname, $dbname, Session::get('db', 'name') == $dbname ? "selected=\"selected\"" : "");
			$HTML->endselect();
		}
		else
		{
			print '<span>Select a database to begin.</span>';
		}
		return $dblist;
	}

	function getDBClass()
	{
		// use least problematic solution when session isn't ready yet
		if ( ! Session::get('auth', 'valid') )
			$lib = "lib/db4.php";
		else if (Session::get('db', 'version') && (Session::get('db', 'version') < 5 ) )
			$lib = "lib/db4.php";
		else if (defined("USE_MYSQLI") && USE_MYSQLI == 1 && extension_loaded('mysqli') )
			$lib = "lib/dbex.php";
		else
			$lib = "lib/db.php";

		return $lib;
	}

	function doWork(&$db)
	{
		//traceMessage("doWork ... [".v($_REQUEST[type])."][".v($_REQUEST[id])."][".v($_REQUEST[name])."]");
		// contents of the iframe
		startForm();

		if ( isset($_REQUEST["type"]) )
		{
			$_REQUEST["query"] = trim(v($_REQUEST["query"], ""), " \t\r\n;");
			$module = "modules/".$_REQUEST["type"].".php";
			if (ctype_alpha($_REQUEST["type"]) && file_exists($module))
			{
				include($module);
				function_exists('processRequest') ? processRequest($db) : createErrorGrid($db, "");
			}
			else
				createErrorPage();		// unidentified type requested
		}
		print "</form>\n";
		print "</body></html>";
	}

	function createResultGrid(&$db)
	{
		traceMessage("createResultGrid...");
		Session::del('select', 'pkey');
		Session::del('select', 'ukey');
		Session::del('select', 'mkey');
		Session::del('select', 'unique_table');  // this is different from the one used for viewing table data

		// <form element is moved to js, see comments there
		print "<div name='results' id='results'>";
		print "<table cellspacing=\"0\" width='100%' border=\"0\" class='results postsort' id=\"dataTable\"><thead>\n";

		$f = $db->getFieldInfo();

		// see if all fields come from one table so we can allow editing
		if (Session::get('select', 'has_limit'))
		{
			Session::set('select', 'unique_table', $f[0]->table);
			for($i=1; $i<count($f);$i++)
			{
				if ($f[$i]->table != Session::get('select', 'unique_table'))	// bail out, more than one table data
				{
					Session::del('select', 'unique_table');
					break;
				}
			}
		}
		// desc command returns table name as COLUMNS, so we make it empty
		//if (Session::get('select', 'unique_table') == "COLUMNS")
		//	Session::del('select', 'unique_table');

		$ed = Session::get('select', 'has_limit') && (Session::get('select', 'unique_table') == "" ? false : true);// && ($db->numRows() > 0);
		// ------------ print header -----------
		print "<tr id=\"fhead\">";
		print "<th class=\"th tch\">#</th>";

		if ($ed)
			print "<th class=\"th_nosort tch\"><input class=\"check-all\" type=\"checkbox\" onclick=\"resultSelectAll()\" title=\"Select/unselect All records\" /></th>";

		$v = "";
		// more than one field can be part of a primary key (composite key)
		Session::set('select', 'pkey', array());
		Session::set('select', 'ukey', array());
		Session::set('select', 'mkey', array());

		$fieldNames = '';
		$fieldInfo = json_encode($f);
		foreach($f as $fn)
		{
			$cls = $fn->type == 'numeric' ? "th_numeric" : "th";
			print "<th nowrap=\"nowrap\" class='$cls'>";
			if ($fn->pkey == 1)
			{
				Session::add('select', 'pkey', $fn->name);
				print "<span class='pk' title='Primary key column'>&nbsp;</span>";
			}
			else if ($fn->ukey == 1)
			{
				Session::add('select', 'ukey', $fn->name);
				print "<span class='uk' title='Unique key column'>&nbsp;</span>";
			}
			else if ($fn->mkey == 1 && !$fn->blob)		// blob/text fields are FULL TEXT KEYS only
				Session::add('select', 'mkey', $fn->name);

			print $fn->name."</th>";
			$fieldNames .= "'" . str_replace("'", "\\'", $fn->name) . "',";
		}

		print "</tr></thead><tbody>\n";

		// ------------ print data -----------
		$j = 0;
		while($r = $db->fetchRow(0, MYSQL_NUM))
		{
			$i = 0;
			print "<tr class=\"row\">";
			print "<td class=\"tj\">".($j+1)."</td>";

			if ($ed)
				print "<td class=\"tch\"><input type=\"checkbox\" /></td>";

			foreach($r as $rs)
			{
				$class = ($rs === NULL) ? "tnl" : ($f[$i]->numeric == 1 ? "tr" : "tl");
				if ($ed) $class .= ' edit';
				if ($f[$i]->blob)
					$class .= $f[$i]->type == 'binary' ? ' blob' : ' text';

				if (!$f[$i]->blob)
					$data = ($rs === NULL) ? "NULL" : (($rs === "") ? "&nbsp;" : htmlspecialchars($rs));
				else
					$data = getBlobDisplay($rs, $f[$i], $j, $ed);

				print "<td nowrap=\"nowrap\" class=\"$class\">$data</td>";
				$i++;
			}
			print "</tr>\n";
			$j++;
			if (Session::get('select', 'has_limit') && MAX_RECORD_TO_DISPLAY > 0 && $j >= MAX_RECORD_TO_DISPLAY)
				break;
		}

		$numRows = $j;
		print "</tbody></table>";
		print "</div>";

		$message = '';
		if (Session::get('select', 'has_limit')) // can limit be applied to this type of query (e.g. show,explain)
		{
			if (Session::get('select', 'limit'))  // yes, and limit is applied to records by the application
			{
				$total_records = Session::get('select', 'count');
				$total_pages = ceil($total_records / MAX_RECORD_TO_DISPLAY);
				$current_page = Session::get('select', 'page');
				$from = (($current_page - 1) * MAX_RECORD_TO_DISPLAY) + 1;
				$to = $from + $db->numRows() - 1;
				$message = "<div class='numrec'>Showing records ".$from." - ".$to."</div>";
			}
			else
			{
				$total_records = $db->numRows();
				$total_pages = 1;
				$current_page = 1;
				if (MAX_RECORD_TO_DISPLAY > 0 && $total_records > MAX_RECORD_TO_DISPLAY)
					$message = "<div class='numrec'>Showing first ".MAX_RECORD_TO_DISPLAY." records only!</div>";
			}
		}
		else
		{
			$total_records = $db->numRows();
			$total_pages = 1;
			$current_page = 1;
			$message = "";
		}
		$js = "<script type=\"text/javascript\" language=\"javascript\">\n";
		if (count(Session::get('select', 'pkey')) > 0)
			$js .= "parent.editKey = ".json_encode(Session::get('select', 'pkey')).";\n";
		else if (count(Session::get('select', 'ukey')) > 0)
			$js .= "parent.editKey = ".json_encode(Session::get('select', 'ukey')).";\n";
		else if (Session::get('select', 'mkey'))
			$js .= "parent.editKey = ".json_encode(Session::get('select', 'mkey')).";\n";
		else
			$js .= "parent.editKey = [];\n";
		$js .= "parent.editTableName = '" . Session::get('select', 'unique_table') ."';\n";
		//$js .=  "parent.fieldInfo = new Array(" . substr($fieldNames,0,strlen($fieldNames)-1) . ");\n" ;
		$js .= "parent.fieldInfo = ".$fieldInfo.";\n";
		$js .= "parent.queryID = '".md5(Session::get('select', 'query'))."';\n";
		$tm = $db->getQueryTime();
		$js .= "parent.totalRecords = $total_records;\n";
		$js .= "parent.totalPages = $total_pages;\n";
		$js .= "parent.currentPage = $current_page;\n";
		$js .= "parent.transferResultGrid(".$numRows.", '$tm', \"$message\");\n";
		$js .= "parent.addCmdHistory(\"".preg_replace("/[\n\r]/", "<br/>", htmlspecialchars(Session::get('select', 'query')))."\", 1);\n";
		$js .= "parent.resetFrame();\n";
		$js .= "</script>\n";

		print $js;
	}

	function createSimpleGrid(&$db, $message)
	{
		traceMessage("createSimpleGrid...");

		print "<div name='results' id='results'>";
		print "<div class='note'>$message</div>";

		print "<table cellspacing=\"0\" width='100%' border=\"0\" class='results' id=\"infoTable\"><thead>\n";

		$f = $db->getFieldInfo();

		$ed = false;
		// ------------ print header -----------
		print "<tr id=\"fhead\">";
		print "<th class=\"th\">#</th>";

		$v = "";

		foreach($f as $fn)
		{
			$cls = $fn->type == 'numeric' ? "th_numeric" : "th";
			print "<th nowrap=\"nowrap\" class='$cls'>";
			print $fn->name."</th>";
		}

		print "</tr></thead><tbody>\n";

		// ------------ print data -----------
		$j = 0;
		while($r = $db->fetchRow(0, MYSQL_NUM))
		{
			$i = 0;
			print "<tr id=\"rc$j\" class=\"row\">";
			print "<td class=\"tj\">".($j+1)."</td>";

			foreach($r as $rs)
			{
				$class = ($rs === NULL) ? "tnl" : ($f[$i]->numeric == 1 ? "tr" : "tl");
				if ($f[$i]->blob)
					$class .= $f[$i]->type == 'binary' ? ' blob' : ' text';

				$data = ($rs === NULL) ? "NULL" : (($rs === "") ? "&nbsp;" : htmlspecialchars($rs));

				print "<td nowrap=\"nowrap\" id=\"r$j"."f$i\" class=\"$class\">$data</td>";
				$i++;
			}
			print "</tr>\n";
			$j++;
		}

		$numRows = $j;
		print "</tbody></table>";
		print "</div>";

		$js = "<script type=\"text/javascript\" language=\"javascript\">\n";
		$tm = $db->getQueryTime();
		$js .= "parent.transferInfoMessage();\n";
		$js .= "parent.resetFrame();\n";
		$js .= "</script>\n";

		print $js;
	}

	function createErrorPage()
	{
		traceMessage("createErrorPage...");
		echo view('error_page');
	}

	// numQueries = number of 'successful' executed queries
	// affectedRows = some rows maybe affected in batch processing, even if error occured
	function createErrorGrid(&$db, $query="", $numQueries=0, $affectedRows=-1)
	{
		traceMessage("createErrorGrid...");

		if ($query == "")
			$query = Session::get('select', 'query');

		Session::del('select', 'result');
		Session::del('select', 'pkey');
		Session::del('select', 'ukey');
		Session::del('select', 'mkey');
		Session::del('select', 'unique_table');

		Session::set('select', 'result', array());		// result blob data
		$e = $db->getError();
		print "<div name='results' id='results'><table cellspacing=5 width='100%' border=0>\n";
		print "<tr><td><div class=\"success\">";
		if ($numQueries > 0)
		{
			print ($numQueries == 1 ? "1 query" : "$numQueries queries");
			print " successfully executed.<br/><br/>$affectedRows record(s) were affected.<br/><br/>";
		}
		//else
		//	print "No query was successful";
		
		$formatted_query = preg_replace("/[\\n|\\r]?[\\n]+/", "<br>", htmlspecialchars($query));
		print "</div></td></tr>";
		print "<tr><td>";
		print "<div class=\"warning\">Error occured while executing the query:</div><div class=\"sql_error\">".$formatted_query."</div><div class=\"message\">".htmlspecialchars($e)."</div>";
		print "</td></tr>";
		print "</table></div>";
		print "<script type=\"text/javascript\" language='javascript'> parent.transferResultMessage(-1, '&nbsp;', 'Error occured while executing the query');\n";
		print "parent.addCmdHistory(\"".preg_replace("/[\n\r]/", "<br/>", htmlspecialchars(Session::get('select', 'query')))."\");\n";
		print "parent.resetFrame();\n";
		print "</script>\n";
	}

	function createInfoGrid(&$db, $query="", $numQueries=1, $affectedRows=-1, $addHistory=true, $executionTime=false)	// batch process will send default params as required
	{
		Session::del('select', 'pkey');
		Session::del('select', 'ukey');
		Session::del('select', 'mkey');
		Session::del('select', 'unique_table');

		if ($affectedRows == -1)
			$affectedRows = $db->getAffectedRows();
		if ($query == "")
			$query = $_REQUEST["query"];
		print "<div name='results' id='results'><table cellspacing=5 width='100%' border=0>\n";
		print "<tr><td><div class=\"success\">";
		print ($numQueries == 1 ? "1 query" : "$numQueries queries");
		print " successfully executed.</div>";
		if ($numQueries == 1)
		{
			$formatted_query = preg_replace("/[\\n|\\r]?[\\n]+/", "<br>", htmlspecialchars($query));
			print "<div class='sql_text'>".$formatted_query."</div>";
		}
		print "<div class=\"message\">$affectedRows record(s) were affected.</div>";
		print "</td></tr>";
		print "</table></div>";
		$tm = $executionTime ? $executionTime : $db->getQueryTime();
		print "<script type=\"text/javascript\" language='javascript'> parent.transferResultMessage(-1, '$tm', '$affectedRows record(s) updated');\n";
		if ($addHistory)
			print "parent.addCmdHistory(\"".preg_replace("/[\n\r]/", "<br/>", htmlspecialchars($query))."\");\n";
		if (Session::get('db', 'altered'))
		{
			Session::del('db', 'altered');
			print "parent.objectsRefresh();\n";
		}
		print "parent.resetFrame();\n";
		print "</script>\n";
	}

	function getQueryType($query)
	{
		$type = array('result'=>FALSE,'has_limit'=>FALSE,'update'=>FALSE);
		$query = trim($query, " \n\t");
		$query = strtolower(substr($query, 0, 7));  // work on only first few required characters of query
		if(substr($query, 0, 6) == "select" || substr($query, 0, 4) == "desc"
					|| substr($query, 0, 7) == "explain" || substr($query, 0, 4) == "show"
					|| substr($query, 0, 4) == "help" )
		{
			$type['result'] = TRUE;
			if (substr($query, 0, 6) == "select")
				$type['has_limit'] = TRUE; // we don't want to limit results for other queries like 'show...'
		}
		else
			$type['update'] = TRUE;

		return $type;
	}

	function getCommandInfo($sql)
	{
		$info = array('db'=>'', 'dbChanged'=>FALSE, 'dbAltered'=>FALSE);
		if (preg_match('@^[\s]*USE[[:space:]]*([\S]+)@i', $sql, $match))
		{
			$info['db'] = trim($match[1], ' ;');
			$info['dbChanged'] = TRUE;
		}
		//else if (preg_match('/^(CREATE|ALTER|DROP)\s+(VIEW|TABLE|DATABASE|SCHEMA)\s+/i', $sql))
		else if (preg_match('/^(CREATE|ALTER|DROP)\s+/i', $sql))
		{
			$info['dbAltered'] = true;
		}
		/*else if (preg_match('@^[\s]*(DROP|CREATE)[\s]+(IF EXISTS[[:space:]]+)?(TABLE|DATABASE)[[:space:]]+(.+)@im', $sql))
		{
		}*/
		
		return $info;
	}

	function startForm($style="margin:0px;overflow:hidden;hwidth:100%;height:100%")
	{
		print "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">";
		print "<html xmlns=\"http://www.w3.org/1999/xhtml\" style=\"overflow:hidden;width:100%;height:100%\">\n";
		print "<head><title>MyWebSql</title>\n";
		print "</head><body style=\"$style\">\n";
		print "<script language='javascript' type='text/javascript' src='cache.php?script=common'></script>\n";
		print "<script language='javascript' type='text/javascript'>
				var EXTERNAL_PATH = '".EXTERNAL_PATH."';
				var THEME_PATH = '".THEME_PATH."';
				</script>\n";
		print "<form name='frmquery' id='frmquery' method='post' action='#' enctype='multipart/form-data' onsubmit='return false'>";
		print "<input type='hidden' name='type' value='query' />";
		print "<input type='hidden' name='id' value='' />";
		print "<input type='hidden' name='name' value='' />";
		print "<input type='hidden' name='query' value='' />";
	}

	function sanitizeCreateCommand($type, $cmd)
	{
		$str = preg_replace("/[\\n|\\r]?[\\n]+/", "<br>", htmlspecialchars($cmd));
		return $str;
		
		/*if ($type == "table")
			return $str;
		else if ($type == "view")
		{
			$str = str_replace(" DEFINER=", "<br>DEFINER=", $str);
			$str = str_replace(" SQL SECURITY ", "<br>SQL SECURITY ", $str);
			$str = str_replace(" AS (", "<br> AS<br>(", $str);
		}
		else if ($type == "procedure")
		{
			$str = str_replace(" DEFINER=", "<br>DEFINER=", $str);
			$str = str_replace(" PROCEDURE ", "<br>PROCEDURE ", $str);
			$str = str_replace("BEGIN", "<br>BEGIN<br>", $str);
			$str = str_replace(" END", "<br>END", $str);
			
		}
		else if ($type == "function")
		{
			$str = str_replace(" DEFINER=", "<br>DEFINER=", $str);
			$str = str_replace(" FUNCTION ", "<br>FUNCTION ", $str);
			$str = str_replace("BEGIN", "<br>BEGIN<br> ", $str);
			$str = str_replace(" END", "<br>END", $str);
		}
		else if ($type == "trigger")
		{
			$str = str_replace("\n", "<br>", $str);
		}
		
		return $str;*/
	}

	function getBlobDisplay($rs, $info, $numRecord, $editable)
	{
		$pattern = '/[\x00-\x08\x0E-\x1F\x7F]/';
		// js = data.test(/[\x00-\x1F]/)
		// data.test(/[\x00-\x1F\x80-\xFF]/)

		$blob_length = strlen($rs);
		$data = '<span class="data">';
		$binary = false;
		if ($rs === NULL)
			$data .= "NULL";
		else if ($rs === "")
			$data .= "&nbsp;";
		else
		{
			$binary = preg_match($pattern, substr($rs, 0, 20));  // use regexp on a small subset of data
			if ($binary) {
				$size = format_bytes($blob_length);
				$data .= 'Binary Data ['.$size.']';
			}
			else
				$data .= (MAX_BLOB_LENGTH_CHECK >= $blob_length) ? htmlspecialchars($rs) 
					: htmlspecialchars(substr($rs, 0, MAX_BLOB_LENGTH_CHECK));
		}

		$extra = "";
		$btype = "";

		if ($editable)
		{
			if ($info->type == 'binary')
			{
				include("config/blobs.php");
				foreach($blobTypes as $k => $v)
				{
					if ( $v[1] && matchFileHeader($rs, $v[1]) )
					{
						traceMessage("auto detected blob type: $k");
						$btype = $k;
						break;
					}
				}
				$extra = "onclick=\"vwBlb($numRecord, '".$info->name."', '$btype')\"";
			}
			else
				$extra = "onclick=\"vwTxt($numRecord, '".$info->name."')\"";
		}
		if ($btype == "")   // generic blob/text data
				$btype = "text";

		if (MAX_BLOB_LENGTH_CHECK < $blob_length && !$binary)
			$data .= "...";
		$data .= "</span>";

		if ($editable)
			$data .= "<span title=\"Click to view/edit column data [$blob_length Bytes]\" class=\"blob $btype\" $extra>&nbsp;</span>";
		return $data;
	}
?>