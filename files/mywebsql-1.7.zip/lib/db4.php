<?php

	/********************************************************************
	*    db.php - Authors: AllyShayan                                   *
	*    This file is a part of MyWebSQL package                        *
	*    A very simple to use and easy to debug mysql wrapper class     *
	*    PHP5 compatible                                                *
	*********************************************************************/

if (defined("CLASS_DB_INCLUDED"))
	return true;

define("CLASS_DB_INCLUDED", "1");

class DbManager
{
	var $ip, $user, $password, $db;
	var $conn;
	var $result;		// array
	var $errMsg;
	var $escapeData;
	var $queryTime;

	function DbManager()
	{
		$this->conn = null;
		$this->errMsg = null;
		$this->escapeData = true;
		$this->result = array();
	}

	function connect($ip, $user, $password, $db="")
	{
		$this->conn = @mysql_connect($ip, $user, $password);
		if (!$this->conn)
			return $this->error(mysql_error());

		if ($db && !@mysql_select_db($db, $this->conn))
			return $this->error(mysql_error($this->conn));

		$this->ip = $ip;
		$this->user = $user;
		$this->password = $password;
		$this->db = $db;
		
		$this->selectVersion();
		$this->query("SET CHARACTER SET 'utf8'");
		
		return true;
	}

	function pconnect($ip, $user, $password, $db)
	{
		log_message("db: pconnecting $ip, $user, $db");
		$this->conn = @mysql_pconnect($ip, $user, $password);
		if (!$this->conn)
			return $this->error(mysql_error());

		if ($db && !@mysql_select_db($db, $this->conn))
			return $this->error(mysql_error($this->conn));
		$this->ip = $ip;
		$this->user = $user;
		$this->password = $password;
		$this->db = $db;
		
		$this->selectVersion();
		
		return true;
	}
	
	function disconnect()
	{
		@mysql_close($this->conn);
		$this->conn = false;
		return true;
	}
	
	function selectDb($db)
	{
		$this->db = $db;
		mysql_select_db($this->db);
	}
	
	function query($sql, $stack=0)		// call with query($sql, 1) to store multiple results
	{
		if (!$this->conn)
			log_message("DB: Connection has been closed");

		$this->result[$stack] = "";
		
		//traceMessage("Query: $sql");
		$this->queryTime = $this->getMicroTime();
		$this->result[$stack] = @mysql_query($sql, $this->conn);
		$this->queryTime = $this->getMicroTime() - $this->queryTime;

		if (!$this->result[$stack])
		{
			$this->errMsg = mysql_error($this->conn);
			log_message("DB: $sql ::: ".@mysql_error($this->conn));
			return false;
		}
		
		return true;
	}

	function getQueryTime($time=false)  // returns formatted given value or internal query time
	{
		return sprintf("%.2f", ($time ? $time : $this->queryTime) * 1000) . " ms";
	}
	
	function hasAffectedRows()
	{
		return ($this->getAffectedRows() > 0);
	}
	
	function insert($table, $values)
	{
		if (!is_array($values))
			return false;
		
		$sql = "insert into $table (";
		
		foreach($values as $field=>$value)
			$sql .= " $field,";
		
		$sql = substr($sql, 0, strlen($sql) - 1);
		
		$sql .= ") values (";
		
		foreach($values as $field=>$value)
		{
			if ($this->escapeData)
				$sql .= "'" . $this->escape($value) . "',";
			else
				$sql .= "'$value',";
		}
		
		$sql = substr($sql, 0, strlen($sql) - 1);
		
		$sql .= ")";
		
		$this->query($sql);
	}
	
	function update($table, $values, $condition="")
	{
		if (!is_array($values))
			return false;
		
		$sql = "update $table set ";
		
		foreach($values as $field=>$value)
		{
			if ($this->escapeData)
				$sql .= "$field = '" . $this->escape($field) . "',";
			else
				$sql .= "$field = '$value',";
		}
		
		$sql = substr($sql, 0, strlen($sql) - 1);
		
		if ($condition != "")
			$sql .= "$condition";
		
		$this->query($sql);
	}
	
	function getInsertID()
	{
		return mysql_insert_id($this->conn);
	}
	
	function getResult($stack=0)
	{
		return $this->result[$stack];
	}
	
	function hasResult($stack=0)
	{
		return ($this->result[$stack] !== TRUE && $this->result[$stack] !== FALSE);
	}
	
	function fetchRow($stack=0, $type="")
	{
		if($type == "")
			$type = MYSQL_BOTH;

		if (!$this->result[$stack])
		{
			log_message("DB: called fetchRow[$stack] but result is false");
			return;
		}
		return @mysql_fetch_array($this->result[$stack], $type);
	}
	
	function fetchSpecificRow($num, $type="", $stack=0)
	{
		if($type == "")
			$type = MYSQL_BOTH;
		
		if (!$this->result[$stack])
		{
			log_message("DB: called fetchSpecificRow[$stack] but result is false");
			return;
		}

		mysql_data_seek($this->result[$stack], $num);
		return @mysql_fetch_array($this->result[$stack], $type);
	}
	
	function numRows($stack=0)
	{
		return mysql_num_rows($this->result[$stack]);
	}
	
	function error($str)
	{
		log_message("DB: " . $str);
		$this->errMsg = $str;
		return false;
	}
	
	function getError()
	{
		return $this->errMsg;
	}
	
	function escape($str)
	{
		return mysql_escape_string($str);
	}
	
	function setEscape($escape=true)
	{
		$this->escapeData = $escape;
	}

	function getAffectedRows()
	{
		return mysql_affected_rows($this->conn);
	}
	
	/**************************************/
	function getDatabases()
	{
		$res = mysql_query("show databases", $this->conn);
		$ret = array();
		while($row = mysql_fetch_array($res))
			$ret[] = $row[0];
		return $ret;
	}
	
	function getTables()
	{
		if (!$this->db)
			return array();
		$res = mysql_query("show tables", $this->conn);
		$ret = array();
		while($row = mysql_fetch_array($res))
			$ret[] = $row[0];
		return $ret;
	}

	// NOT SUPPORTED IN MYSQL 4 - Function are here for code compatibility reasons only
	function getViews()
	{
		$ret = array();
		return $ret;
	}
	
	function getProcedures()
	{
		$ret = array();
		return $ret;
	}
	
	function getFunctions()
	{
		$ret = array();
		return $ret;
	}
	
	function getTriggers()
	{
		$ret = array();
		return $ret;
	}
	
	/**************************************/
	function getFieldInfo($stack=0)
	{
		$fields = array();
		$i = 0;
		while ($i < mysql_num_fields($this->result[$stack]))
		{
			$meta = mysql_fetch_field($this->result[$stack], $i);
			if ($meta)
			{
				$f = new StdClass;
				$type = mysql_field_type($this->result[$stack], $i);
				$f->name = $meta->name;
				$f->table = $meta->table;
				$f->not_null = $meta->not_null;
				$f->blob = $meta->blob;
				$f->pkey = $meta->primary_key;
				$f->ukey = $meta->unique_key;
				$f->mkey = $meta->multiple_key;
				$f->zerofill = $meta->zerofill;
				$f->unsigned = $meta->unsigned;
				$f->autoinc = 0;//($meta->flags & AUTO_INCREMENT_FLAG) ? 1 : 0;
				$f->numeric = $meta->numeric;

				$f->type = ($type == 'string' ? 'char' : 'binary');
				/*if ($meta->flags & ENUM_FLAG)
					$f->type = 'enum';
				else if ($meta->flags & SET_FLAG)
					$f->type = 'set';
				else if ($meta->flags & BINARY_FLAG)
					$f->type = 'binary';
				else if ($meta->type < 10)
					$f->type = 'numeric';
				else
					$f->type = 'char';*/
				$fields[] = $f;
			}
			$i++;
		}
		return $fields;
	}
	
	function getMicroTime()
	{
		list($usec, $sec) = explode(" ",microtime());
		return ((float)$usec + (float)$sec);
	}
	
	function selectVersion()
	{
		$res = mysql_query("SHOW VARIABLES LIKE 'version'", $this->conn);
		$row = mysql_fetch_array($res);
		Session::set('db', 'version', intval($row[1]));
		Session::set('db', 'version_full', $row[1]);
	}
	
	function getCreateCommand($type, $name)
	{
		$cmd = '';
		$type = $this->escape($type);
		$name = $this->escape($name);

		if ($type != "table")
			return '';

		$sql = "show create $type `$name`";

		if (!$this->query($sql) || $this->numRows() == 0)
			return '';
		
		$row = $this->fetchRow();

		$cmd = $row[1];
		return $cmd;
	}
	
	function getFieldValues($table, $name)
	{
		$sql = 'show full fields from `'.$table.'` where `Field` = \''.$this->escape($name).'\'';
		$res = mysql_query($sql, $this->conn);
		if (mysql_num_rows($res) == 0)
			return ( (object) array('list' => array()) );
		$row = mysql_fetch_array($res);
		$type = $row['Type'];
		preg_match('/enum\((.*)\)$/', $type, $matches);
		if (!isset($matches[1]))
			preg_match('/set\((.*)\)$/', $type, $matches);
		if (isset($matches[1]))
		{
			$list = explode(',', $matches[1]);
			foreach($list as $k => $v)
				$list[$k] = str_replace("\\'", "'", trim($v, " '"));
			return $list;
		}
		return ( (object) array('list' => array()) );
	}
	
	function getEngines()
	{
		$sql = 'show engines';
		$res = mysql_query($sql,$this->conn);
		if (mysql_num_rows($res) == 0)
			return ( array() );
		
		$arr = array();
		while($row = mysql_fetch_array($res))
			if ($row['Support'] != 'NO')
				$arr[] = $row['Engine'];
		return $arr;
	}
	
	function getCharsets()
	{
		$sql = 'show character set';
		$res = mysql_query($sql,$this->conn);
		if (mysql_num_rows($res) == 0)
			return ( array() );
		
		$arr = array();
		while($row = mysql_fetch_array($res))
			$arr[] = $row['Charset'];

		asort($arr);
		return $arr;
	}
	
	function getCollations()
	{
		$sql = 'show collation';
		$res = mysql_query($sql,$this->conn);
		if (mysql_num_rows($res) == 0)
			return ( array() );
		
		$arr = array();
		while($row = mysql_fetch_array($res))
			$arr[] = $row['Collation'];

		asort($arr);
		return $arr;
	}
	
	function getTableProperties($table) {
		$sql = "show table status like '".$this->escape($table)."'";
		if (!$this->query($sql, "_tmp_query"))
			return FALSE;
		return $this->fetchRow("_tmp_query");
	}
	
	function queryTableStatus() {
		$sql = "show table status";
		return $this->query($sql);
	}
}
?>