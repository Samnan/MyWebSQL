/***********************************************
 *	interface.js - Author: Samnan ur Rehman     *
 *	This file is a part of MyWebSQL package     *
 ***********************************************/

var main_layout;
var data_layout;
var commandEditor;

var currentTreeItem = null;
var clipboard_helper = null;

$(document).ready(function () {

	$('body').bind('contextmenu', function() { return false; });
	// main menu setup - @todo: find a fix for the menu close problem (css issue)
	$("ul#main-menu li ul li:has(ul)").find("a:first").append(" &raquo; ");
	$("ul#main-menu").find("a").click(function(event) {
		event.stopPropagation();
		$(this).blur();
	});
	$('ul#main-menu li').click(function() { eval($(this).find('a').attr('href')); });
	$('#toolbarHolder').mouseover(function() { if (_contextMenu) _contextMenu.hide(); });

	$(".ui-layout-data-center").tabs(); // make tabs first to avoid resize problems
	$(".ui-layout-data-south").tabs({
		select: function(event, ui) { setTimeout(focusEditor, 200); }
	});

	main_layout = $('body').layout({
		spacing_open: 3
		,spacing_closed: 3
		,north__resizable: false
		,north__closable: false
		,north__spacing_open: 0
		,north__spacing_closed: 0
		,south__resizable: false
		,south__closable: false
		,south__spacing_open: 0
		,south__spacing_closed: 0
		,west__minSize: 150
		,west__size: $('body').innerWidth() * 0.2
		,east__minSize: 200
		,center__onresize:		"data_layout.resizeAll"
		,enableCursorHotkey: false
		//,useStateCookie: true
		//,cookie: { name: 'main' }
	});

	data_layout = $('div.ui-layout-center').layout({
		spacing_open: 3
		,spacing_closed: 3
		,center__paneSelector:		".ui-layout-data-center"
		,south__paneSelector:		".ui-layout-data-south"
		,center__resizable: true
		,south__resizable: true
		,south__closable: true
		,south__minSize: 72
		,south__size: 160
		,enableCursorHotkey: false
		//,useStateCookie: true
		//,cookie: { name: '' }
	});

	main_layout.allowOverflow('north');
	if (sqlEditMode != 1)
		initStart();

	$(".ui-layout-data-center").tabs('select', 2);
	
	$('#dialog_contents').bind('load', function() { updatePopup(1); });
	$("#dialog").dialog({
		//bgiframe: true,
		autoOpen: false,
		width:500,
		height: 300,
		minWidth: 460,
		minHeight: 260,
		modal: true,
		open: function() { $('#dialog_contents').height($('.ui-dialog').height()).width($('.ui-dialog').width()); }
	});
	$('#dialog').bind('dialogresizestart dialogdragstart', function() {
		iframe = $('#dialog_contents');
		var d = $('<div></div>');
		$('#dialog').append(d[0]);
		d[0].id = 'dialog_frame_div';
		d.css({position:'absolute'});
		d.css({top: 0, left:0});
		d.height(iframe.height());
		d.width('100%');
	});
	$('#dialog').bind('dialogresizestop dialogdragstop', function() {
		$('#dialog_frame_div').remove();
		$('#dialog_contents').height($('.ui-dialog').height()).width($('.ui-dialog').width());
	});

	$("#dialog-dbcreate").dialog({
		autoOpen: false,
		width:320,
		height: 160,
		modal: true,
		buttons: {
			'Cancel': function() {
				$(this).dialog('close');
			},
			'Create Database': function() {
				dbCreate(1);
			}
		}
	});

	$("#tablelist").treeview();

	contextHandler();

	// chrome selection issue fix when a resizer is used for rsizing
	$('.ui-layout-resizer').bind('selectstart', function() { return false; });

	$('#nav_query').button({
		text: true,	icons: {primary: 'ui-icon-play'}
	}).click(function() { queryGo(0); });
	$('#nav_queryall').button({
		text: true,	icons: {primary: 'ui-icon-seek-end'}
	}).click(function() { queryGo(1); });
	$('#nav_delete').button({
		text: true,	icons: {primary: 'ui-icon-close'}
	}).click(function() { queryDelete(); });
	$('#nav_update').button({
		text: true,	icons: {primary: 'ui-icon-disk'}
	}).click(function() { querySave(); });
	$('#nav_gensql').button({
		text: true,	icons: {primary: 'ui-icon-script'}
	}).click(function() { queryGenerate(); });
	$('#nav_addrec').button({
		text: true,	icons: {primary: 'ui-icon-plusthick'}
	}).click(function() { queryAddRecord(); });
	$('#nav_refresh').button({
		text: true,	icons: {}
	}).click(function() { queryRefresh(); });

	initClipboard();
	
	//main_layout.load('layout');
	//$('#dblist').combobox();
	setTimeout(infoDefault, 300); // avoid ie frame load issues ...
});

function contextHandler() {
	$('#tablelist .odb').contextMenu('#db-menu');
	$('#tablelist .otable').contextMenu('#table-menu');
	$('#tablelist .oview').contextMenu('#view-menu');
	$('#tablelist .oproc').contextMenu('#proc-menu');
	$('#tablelist .ofunc').contextMenu('#func-menu');
	$('#tablelist .otrig').contextMenu('#trig-menu');
	
	// by default we setup context menus for everything
	if(arguments.length == 0) {
		$("#object_list").contextMenu('#panel-menu-objects');
		$("#sql-editor-pane").contextMenu('#panel-menu-editor');
		$("#sql-history").contextMenu('#history-menu');
		
		if (DB_VERSION < 5)
			$('ul#main-menu .m5').remove();
	}
}

function initClipboard() {
	// copying using zeroclipboard and context menu is a pain... but we have to do it ...
	ZeroClipboard.setMoviePath('js/jquery.clipboard.swf');
	clipboard_helper = new ZeroClipboard.Client();
	$('#history-menu li.clipboard').mouseover(function() {
		clipboard_helper.setText(getHistoryText());
		if (clipboard_helper.div) {
			clipboard_helper.receiveEvent('mouseout', null);
			clipboard_helper.reposition(this);
		}
		else {
			clipboard_helper.glue(this);
			$(clipboard_helper.div).click(function() {
				clipboard_helper.hide();
			});
		}
		clipboard_helper.receiveEvent('mouseover', null);
	});
}

function showNavBtns() {
	bn = new Array("addrec", "query", "queryall", "delete", "update", "gensql");
	for(i=0; i<bn.length; i++)
		$('#nav_' + bn[i]).css("display", "none");

	for(i=0; i<arguments.length; i++)
		$('#nav_' + arguments[i]).css("display", "block");
}

function showNavBtn() {
	for(i=0; i<arguments.length; i++)
		$('#nav_' + arguments[i]).css("display", "block");
}

function hideNavBtn(btn) {
	for(i=0; i<arguments.length; i++)
		$('#nav_' + arguments[i]).css("display", "none");
}

function editorHotkey(code, fn) {
	$(document.getElementById('sqlEditFrame').contentWindow.document).bind('keydown', code, fn);
	$(document.getElementById('sqlEditFrame2').contentWindow.document).bind('keydown', code, fn);
	$(document.getElementById('sqlEditFrame3').contentWindow.document).bind('keydown', code, fn);
}

function switchEditor(n) {
	$(".ui-layout-data-south").tabs('select', n);
}

function currentEditor() {
	n = $(".ui-layout-data-south").tabs('option', 'selected');
	obj = commandEditor;
	switch(n) {
		case 1: obj = commandEditor2; break;
		case 2: obj = commandEditor3; break;
	}
	
	return obj;
}

function focusEditor() {
	ed = currentEditor();
	ed.focus();
}

function getDataMenu(m, t, e) {
	target = $(e.originalTarget);
	
	if (target.hasClass('tch'))
		return false;
	
	if (target.is('th'))
		return $('#data-menu-th').clone();
	else if (target.is('td'))
		return $('#data-menu-td').clone();
	
	return false; // no menu here
}

function objListHandler(data) {
	tree = $(data).find('#objlist').html();
	if (tree != '') {
		$('#object_list').html(tree);
		$("#tablelist").treeview();
		contextHandler(false);
	}
	else
		jAlert('An error occured while refreshing the object list.');
	setPageStatus(false);
}
//$(window).unload(function(){ main_layout.save('layout') });