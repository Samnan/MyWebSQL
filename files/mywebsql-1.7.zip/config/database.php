<?php

	/************************************************************************
	 *  database.php                                                        *
	 *  main database configuration file                                    *
	 *  Notes:                                                              *
	 *     if "DB_DATABASE" is defined, mywebsql will only work for this db *
	 *     otherwise, the interface will show list of database to work with *
	 ************************************************************************/

	// OBSOLETE
	// see auth.php in the same folder instead for login and access related information
	/*$DB_CONFIG = array(
				"Localhost" => array("host"=>"127.0.0.1", "user"=>"root", "pass"=>""),
				"Connection 2" => array("host"=>"127.0.0.1", "user"=>"root", "pass"=>"", "db"=>"test")	// a restricted user for testing
				);
		*/
?>