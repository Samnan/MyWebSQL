<link href='cache.php?css=theme,default,grid,alerts,mysqlcolors' rel="stylesheet" />

<div id="popup_wrapper">
	<div id="popup_contents">
		<div id="grid-messages">{{MESSAGE}}</div>

		<div id="grid-tabs">
			<ul>
				<li><a href="#tab-fields">Basic Information</a></li>
				<li><a href="#tab-props">Table Properties</a></li>
				<li><a href="#tab-messages">Messages</a></li>
			</ul>
			<div class="ui-corner-bottom">
				<div id="tab-fields">
					<div class="input">
						<span>Table Name:</span><span><input type="text" size="20" name="table-name" id="table-name" value="{{TABLE_NAME}}" /><span>
					</div>
					<table border="0" cellspacing="1" cellpadding="2" id="table_grid"><tbody>
						<tr id='fhead'>
							<th style="width:120px">Field Name</th>
							<th style="width:75px">Data Type</th>
							<th style="width:65px">Length</th>
							<th style="width:90px">Default value</th>
							<th style="width:65px">Unsigned</th>
							<th style="width:65px">Zero Fill</th>
							<th style="width:85px">Primary Key</th>
							<th style="width:100px">Auto Increment</th>
							<th style="width:70px">Not NULL</th>
						</tr>
					</tbody></table>
				</div>
				<div id="tab-props">
					<div class="input"><span>Table Engine (type):</span><span><select name="enginetype" id="enginetype">{{ENGINE}}</select><span></div>
					<div class="input float"><span>Character Set:</span><span><select name="charset" id="charset">{{CHARSET}}</select><span></div>
					<div class="input"><span>Collation:</span><span><select name="collation" id="collation">{{COLLATION}}</select><span></div>
					<div class="input"><span>Comment:</span><span><input type="text" size="40" name="comment" id="comment" value="{{COMMENT}}" style="width:488px" /><span></div>
				</div>
				<div id="tab-messages">
					Waiting for table information to be submitted.
				</div>
			</div>
		</div>
	</div>

	<div id="popup_footer">
		<div id="popup_buttons">
			<input type='button' id='btn_add' value='Add field' />
			<input type='button' id='btn_del' value='Delete selected field' />
			<input type='button' id='btn_submit' value='Submit' tabindex="1" />
			<input type='button' id='btn_clear' value='Clear Table Information' />
		</div>
	</div>

</div>

<div id="dialog-list" title="List of values">
	<div class="padded">
		<div>
			<select size="8" name="list-items" id="list-items"></select>
		</div>
		<div>
			<input type="text" name="item" id="item" class="text ui-widget-content" />
		</div>
	</div>
</div>

<div id="popup_overlay" class="ui-widget-overlay ui-helper-hidden"></div>

<script type="text/javascript" language='javascript' src="cache.php?script=common,jquery,ui,editable,position,query,cookies,settings,alerts,hotkeys"></script>
<script type="text/javascript" language="javascript">

var rowInfo = {{ROWINFO}};

$(function() {
	setupEditable({{ALTER_TABLE}});
});
</script>