<link href='cache.php?css=theme,default,grid,alerts,mysqlcolors' rel="stylesheet" />

<div id="popup_wrapper">
	<div id="popup_contents">
		<div id="blob-holder">
			<pre class="blob" id="blob-data">{{BLOBDATA}}</pre>
		</div>
	</div>
	
	<div id="popup_footer">
		<div id="popup_buttons">
			{{BLOB_TOOLBAR}}
			Show blob data as:&nbsp;&nbsp;
			<select name='blobtype' onchange="blobChangeType()">{{BLOBOPTIONS}}</select>
	</div>
</div>
<div id="popup_overlay" class="ui-widget-overlay ui-helper-hidden"></div>

<input type="hidden" name="act" value="" />
<input type="hidden" name="blob_value" value="" />

<script type="text/javascript" language='javascript' src="cache.php?script=common,jquery,ui,query,cookies,settings,alerts,blobs"></script>
<script type="text/javascript" language="javascript">
$(function() {
	document.frmquery.type.value = 'viewblob';
	document.frmquery.id.value = '{{ID}}';
	document.frmquery.name.value = '{{NAME}}';
	document.frmquery.query.value = '{{QCODE}}';
	parent.updatePopupTitle('Blob/Text data for column {{NAME}}');
	var table = "{{TABLE}}";
	
	$('#btnEditBlob').button().click(blobEdit);
	$('#btnCancel').button().click(blobCancelEdit);
	$('#btnSaveBlob').button().click(blobSave);
	
	$('#btnCancel').hide();
	$('#btnSaveBlob').hide();
});
</script>


