<link href="cache.php?css=theme,default,help" rel="stylesheet" />

<div id="popup_wrapper">

	<div class="ui-widget ui-state-highlight ui-corner-all" style="padding:6px;margin-bottom:5px">
		To see most up-to-date help contents, please visit&nbsp;
		<a target="_blank" href="{{PROJECT_SITEURL}}/docs" style="font-weight:bold">MyWebSql Online Documentation</a>
	</div>
	
	<ul class="links">
	{{LINKS}}
	</ul>
	<div class="content">
	{{CONTENT}}
	</div>

</div>

<script language="javascript" src="cache.php?script=jquery,help" type="text/javascript"></script>
<script type="text/javascript" language="javascript">
	$(function() {
		$('ul.links a').click(function() {
			page = $(this).attr('href').replace('#', '');
			showHelpPage(page);
		});
		parent.updatePopupTitle('Help');
	});
</script>