<div name='results' id='results'>
	<div class='heading1'>Server/Connection information</div>
	<div class="hinfo">
		<div class="label">Mysql version</div><div class="info">{{SERVER_VERSION}}</div>
		<div class="label">Version comment</div><div class="info">{{SERVER_COMMENT}}</div>
	</div>
	<div class='heading1'>Character sets</div>
	<div class="hinfo">
		<div class="label">Server character set</div><div class="info">{{SERVER_CHARSET}}</div>
		<div class="label">Client character set</div><div class="info">{{CLIENT_CHARSET}}</div>
		<div class="label">Database character set</div><div class="info">{{DATABASE_CHARSET}}</div>
		<div class="label">Results character set</div><div class="info">{{RESULT_CHARSET}}</div>
	</div>
</div>

<script type="text/javascript" language="javascript">
parent.transferInfoMessage();
{{JS}}
</script>
