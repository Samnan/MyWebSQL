<?php

	/********************************************************************
	*	dbcreate.php - Author: Samnan ur Rehman							*
	*	This file is a part of MyWebSQL package							*
	*	PHP5 compatible													*
	*********************************************************************/

	function processRequest(&$db)
	{
		Session::del('select', 'result');
		Session::del('select', 'pkey');
		Session::del('select', 'ukey');
		Session::del('select', 'mkey');
		Session::del('select', 'unique_table');
		
		Session::set('select', 'result', array());

		$dbName = $_REQUEST["name"];
		$dbSelect = $_REQUEST["query"];

		$sql = "create database `".$db->escape($dbName)."`";
		Session::set('select', 'query', $sql);
		if (!$db->query($sql))
			createErrorGrid($db);
		else
		{
			print "<div name='results' id='results'><div class=\"success\">New database [ ".htmlspecialchars($dbName). " ] successfully created</div></div>";
			print "<script type=\"text/javascript\" language='javascript'>parent.addCmdHistory(\"".preg_replace("/[\n\r]/", "<br/>", htmlspecialchars($sql))."\");\n";
			$tm = $db->getQueryTime();
			print "parent.transferResultMessage(-1, '$tm', 'New database successfully created');\n";
			if ($dbSelect)
			{
				Session::set('db', 'changed', true);
				Session::set('db', 'name', $dbName);
				print "parent.window.location = parent.window.location;\n";
			}
			print "</script>";
		}
	}
?>