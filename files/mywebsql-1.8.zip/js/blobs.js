/*********************************************
 *	blobs.js - Author: Samnan ur Rehman       *
 *	This file is a part of MyWebSQL package   *
 ********************************************/

function blobChangeType() {
	id = document.frmquery.id.value;
	name = document.frmquery.name.value;
	query = document.frmquery.query.value;
	x = document.frmquery.blobtype.selectedIndex;
	wrkfrmSubmit("viewblob", id, name, query);
}

function blobEdit() {
	pre = $('#blob-data');
	blob = pre.html();
	document.frmquery.blob_value.value = blob;  // save original value
	w = pre.parent().width() - 10;
	h = pre.parent().height() - 10;
	pre.html('<textarea class="blobeditor" style="width:' + w + 'px;height:' + h + 'px" name="blobdata">' + blob + '</textarea>');
	$('#btnEditBlob').hide();
	$('#btnCancel').show();
	$('#btnSaveBlob').show();
}

function blobSave() {
	id = document.frmquery.id.value;
	name = document.frmquery.name.value;
	query = document.frmquery.query.value;
	document.frmquery.act.value = 'save';
	wrkfrmSubmit("viewblob", id, name, query);
}

function blobCancelEdit() {	
	pre = $('#blob-data');
	blob = document.frmquery.blob_value.value;
	pre.text(blob);
	$('#btnCancel').hide();
	$('#btnSaveBlob').hide();
	$('#btnEditBlob').show();
}