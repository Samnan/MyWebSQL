<?php

	/***********************************************
	*  tableupdate.php - Author: Samnan ur Rehman  *
	*  This file is a part of MyWebSQL package     *
	*  PHP5 compatible                             *
	***********************************************/

	function processRequest(&$db)
	{
		/*Session::del('select', 'result');
		Session::del('select', 'pkey');
		Session::del('select', 'ukey');
		Session::del('select', 'mkey');
		Session::del('select', 'unique_table');
		
		Session::set('select', 'result', array());
		*/

		$tbl = $db->escape($_REQUEST["name"]);

		$sql = "show full fields from `".$db->escape($tbl)."`";
		//Session::set('select', 'query', $sql);
		if (!$db->query($sql))
			createErrorGrid($db, $sql);
		else
		{
			$pKey = '';  // if a primary key is available, this helps avoid multikey attributes in where clause
			$str2 = "";
			$str = "update `".$tbl."` set ";
			$num = $db->numRows();
			$row = $db->fetchRow();

			$str .= "`" . $row[0] . "`=\"\"";
			if ($row["Key"] != "")
					$str2 .= "`$row[0]`=\"\"";
			if ($row["Key"] == 'PRI')
				$pKey = $row[0];
			
			for($i=1; $i<$num; $i++)
			{
				$row = $db->fetchRow();
				$str .= ",`" . $row[0] . "`=\"\"";
				if ($row["Key"] != "")
				{
					if ($row["Key"] == 'PRI')
						$pKey = $row[0];
					if ($str2 != "")
						$str2 .= " and ";
					$str2 .= "`$row[0]`=\"\"";
				}
			}

			// if we found a primary key, then use it only for where clause and discard other keys
			if ($pKey != '')
				$str2 = "`$pKey`=\"\"";
			if ($str2 != "")
				$str2 = " where " . $str2;

			print "<div name='results' id='results'>".htmlspecialchars($str.$str2)."</div>";
			print "<script type=\"text/javascript\" language='javascript'> parent.transferQuery(); </script>\n";
		}
	}
?>