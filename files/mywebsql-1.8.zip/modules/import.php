<?php

	/**********************************************
	*  import.php - Author: Samnan ur Rehman      *
	*  This file is a part of MyWebSQL package    *
	*  Contains code for data import              *
	*  PHP5 compatible                            *
	***********************************************/

	function processRequest(&$db)
	{
		$importDone = FALSE;
		$message = '';
		if (isset($_FILES['impfile']))
		{
			if (v($_FILES['impfile']['tmp_name']) != '' && file_exists($_FILES['impfile']['tmp_name']))
			{ 
				include("lib/sqlparser.php");
				$parser = new sqlParser($db);
				$parser->stopOnError(v($_REQUEST['ignore_errors']) == 'yes' ? FALSE : TRUE);
				//$parser->collectStats(v($_REQUEST['stats']) == 'yes');
				$result = $parser->parse($_FILES['impfile']['tmp_name'], $_FILES['impfile']['size'], $_FILES['impfile']['name']);
				
				$executed = $parser->getExecutedQueries();
				$failed = $parser->getFailedQueries();
				if (!$result || $executed > 0 || $failed > 0)
				{
					$message .= '<div class="success">'.$executed.' queries executed successfully [ '
						. $parser->getRowsAffected(). ' row(s) affected. ]</div>';
					if ($failed > 0)
					{
						$failed .= ($failed > 1) ? ' queries' : ' query';
						$message .= '<div class="warning">'.$failed.' failed to execute.</div>';
						if ($failed == 1)
						{
							$message .= '<div class="sql_error">' . htmlspecialchars($parser->getLastQuery()) . '</div>';
							$message .= '<div class="message">' . htmlspecialchars($parser->getError()) . '</div>';
						}
					}
				}
				else
					$message .= '<div class="success">No queries were executed during import.</div>';
			}
			else
				$message .= '<div class="warning">File upload failed. Please try again.</div>';
			
			$importDone = TRUE;
		}
		
		if (!$importDone)
		{
			$max_upload_size = min(bytes_value(ini_get('post_max_size')), bytes_value(ini_get('upload_max_filesize'))) / 1024;
			$max_upload_size = ($max_upload_size < 1024) ? $max_upload_size.'KB' : ($max_upload_size/1024).' MB';
			$message = '<div class="sql_text">Import will execute all queries in a given file one by one<br />Maximum upload filesize is '. $max_upload_size. '<br/>Supported filetypes / extensions are: (' . valid_import_files() . ')</div>';
		}
		
		$replace = array('MESSAGE' => $message);
		echo view('import', $replace);
	}

	function valid_import_files()
	{
		$files = '*.sql, *.txt';
		if (function_exists('bzopen'))
			$files .= ', *.bz, *.bzip, *.bz2';
		if (function_exists('gzopen'))
			$files .= ', *.gz, *.gzip';
		return $files;
	}
?>