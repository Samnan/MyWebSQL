<div name='results' id='results'>
	<div class='heading1'>Table information</div>
	
</div>

<script type="text/javascript" language="javascript">
parent.transferInfoMessage();
</script>
