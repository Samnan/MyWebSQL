<div class="toolbar ui-dialog-titlebar ui-widget-header ui-corner-all ui-helper-clearfix">
	<ul id="main-menu" class="dropdown">
		<li>
			<a href="javascript:void(0)">Database</a>
			<ul>
				<li class="db"><a class="db_refresh" href="javascript:objectsRefresh()" title="Refresh database objects">Refresh</a></li>
				<li><a href="javascript:dbCreate()" title="Create a new database">Create new...</a></li>
				<li class="db"><a href="javascript:dataExport()" title="Export database to batch file as sql dump">Export...</a></li>
			</ul>
		</li>
		<li class="db">
			<a href="javascript:void(0)">Objects</a>
			<ul>
				<li><a class="otable" href="javascript:tableCreate()" title="Create a new table in the database">Create Table...</a></li>
				<li class="m5"><a class="oview" href="javascript:objCreate(1)" title="Create a new view in the database">Create View...</a></li>
				<li class="m5"><a class="oproc" href="javascript:objCreate(2)" title="Create a new stored procedure in the database">Create Stored Procedure...</a></li>
				<li class="m5"><a class="ofunc" href="javascript:objCreate(3)" title="Create a new user defined function in the database">Create Function...</a></li>
				<li class="m5"><a class="otrig" href="javascript:objCreate(4)" title="Create a new trigger in the database">Create Trigger...</a></li>
				<li class="m5"><a class="oevt" href="javascript:objCreate(5)" title="Create a new event in the database">Create Event...</a></li>
			</ul>
		</li>

		<li>
			<a href="javascript:void(0)">Data</a>
			<ul>
				<li><a href="javascript:dataImport()" title="Import multiple queries from batch file">Import batch file...</a></li>
				<li class="db"><a href="javascript:dataExport()" title="Export database to batch file as sql dump">Export database...</a></li>
				<li class="db"><a href="javascript:resultsExport()" title="Export query results to clipboard or files">Export current results...</a></li>
			</ul>
		</li>

		<li>
			<a href="javascript:void(0)">Tools</a>
			<ul>
				<!--li><a href="javascript:toolsOptions()" title="Configure application options">Options</a></li-->
				<li><a href="javascript:toolsProcManager()" title="View and manage database processes">Process Manager</a></li>
			</ul>
		</li>

		<li>
			<a href="javascript:void(0)">Information</a>
			<ul>
				<li><a href="javascript:infoServer()" title="View mysql server details">Server/Connection Details</a></li>
				<li><a href="javascript:infoVariables()" title="View mysql server variables">Server Variables</a></li>
				<li class="db"><a href="javascript:infoDatabase()" title="View current database summary stats">Database Summary</a></li>
			</ul>
		</li>

		<li>
			<a href="javascript:void(0)">Interface</a>
			<ul>
				<li><a href="javascript:void(0)">UI Theme</a>
					<ul>
						{{THEMES_MENU}}
					</ul>
				</li>
				<li><a href="javascript:void(0)">Show/Hide Panel</a>
					<ul>
						<li><a href="javascript:main_layout.toggle('west')" title="Toggle Object Viewer">Database Objects</a></li>
						<li><a href="javascript:data_layout.toggle('south')" title="Toggle Sql Editor">Sql Editor</a></li>
					</ul>
				</li>
			</ul>
		</li>

		<li>
			<a href="javascript:void(0)">Help</a>
			<ul>
				<li><a href="javascript:helpShowAll()" title="Learn the basics of using MyWebSql">Help contents</a></li>
				<li class="db"><a href="javascript:helpQuickTutorial()" title="See quick hands-on tutorial of MyWebSql interface">QuickStart Tutorials</a></li>
				<li><a href="javascript:helpOnlineDocs()" title="Visit online documentation on project website">Online documentation</a></li>
				<li><a href="javascript:helpRequestFeature()" title="If you would like your most favourite feature to be part of MyWebSql, please click here to inform about it">Request a Feature...</a></li>
				<li><a href="javascript:helpReportBug()" title="If you have found a problem, or having trouble using the application, please click here to report the problem">Report a Problem...</a></li>
				<!--li><a href="javascript:helpCheckUpdates()" title="Check for updated versions of the application online">Check for updates...</a></li-->
			</ul>
		</li>
		
		<li class="right"><a href="javascript:logout()" title="Logout from this session">Logout</a></li>
	</ul>
</div>