	<div class="heading">Credits</div>
		<div>Following softwares/people were extremely helpful during the development of MyWebSql.</div>
		<ul>
			<li>jQuery<br>Starting with version 1.0, the whole interface for MyWebSql is designed using jQuery, one of the finest Javascript library in the world.</li>
			<li>jQuery UI<br>A rather not-so-lightweight, but extremely useful GUI and widget library for jQuery.</li>
			<li>Plugins<br>Many useful jQuery plugins are used for client side functionality in MyWebSql.</li>
			<li>CodeMirror<br>Finest javascript code editor i could find on the web. Great support from the developers makes it ideal for use in MyWebSql. Minor modifications were done to make it compatible with sql editing inside this application.</li>
			<li>phpMyAdmin<br>Perhaps the most widely used web based mysql client. Some part of mysql batch import code from the software is incorporated into Mywebsql.</li>
		</ul>
		<ul>
			<li>Project website is hosted on server provided by Ovais Tariq</li>
			<li>Mysql 4 support was added to the software by Ally Shayan.</li>
			<li>Most of the icons / graphics work is based on famfam icons and xiao icons.</li>
			<li>If you believe any graphics used in this application are not supposed to be free for use, Please report back to me as soon as possible so I can fix the problem.</li>
		</ul>
	</div>
