<div class="auth">
	<div>
		<label>User ID:</label><input type="text" name="auth_user" size="30" value="{{LOGINID}}"/>
	</div>
	<div>
		<label>Password:</label><input type="password" name="auth_pwd" size="30" />
	</div>
	<div>
		<input type="submit" value="  Login  " />
	</div>
</div>
<script language="javascript" type="text/javascript">
document.dbform.auth_user.focus();
</script>