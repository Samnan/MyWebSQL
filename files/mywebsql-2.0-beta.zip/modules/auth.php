<?php

	/**********************************************
	*	auth.php - Author: Samnan ur Rehman       *
	*	This file is a part of MyWebSQL package   *
	*	PHP5 compatible                           *
	**********************************************/

	class MyWebSQL_Authentication {
		private $error;
		private $username;
		private $password;
		private $db;

		public function authenticate($DB) {

			$this->db = $DB;
			$error = '';
			$username = '';
			$password = '';

			// change of auth type at runtime invalidates session
			if (Session::get('auth', 'type') != AUTH_TYPE)
				Session::del('auth', 'valid');

			if (Session::get('auth', 'valid'))
				return $this->setParameters();

			if (!$this->checkEnvironment())
				return false;

			if (AUTH_TYPE == 'NONE')
				$this->getAuthNone();
			else if (AUTH_TYPE == 'BASIC')
				$this->getAuthBasic();
			else if (AUTH_TYPE == 'LOGIN') {
				if (secureLoginPage())
					$this->getAuthSecureLogin();
				else
					$this->getAuthLogin();
			}
			
			if (Session::get('auth', 'valid'))
				return $this->setParameters();

			return false;
			/*
			if (is_array($DB_CONFIG) && count($DB_CONFIG) > 0)
			{
				if (isset($_REQUEST["conn"]))
				{
					if (isset($DB_CONFIG[$_REQUEST["conn"]]))
					{
						$_SESSION["conn"] = $_REQUEST["conn"];
						$_SESSION["dblist"] = false;	// if db is set, user will be restricted to this db only
						if (isset($DB_CONFIG[$_REQUEST["conn"]]["db"]))
							$_SESSION["db"] = $DB_CONFIG[$_REQUEST["conn"]]["db"];
						else
						{
							$_SESSION["db"] = "";
							$_SESSION["dblist"] = true;		// show all databases
						}
						$_SESSION["init"] = 1;
					}
				}
				if (v($_SESSION["init"]) != 1)
				{
					include("modules/splash.php");
					die(getSplashScreen());
				}
			}
			else
			{
				$_SESSION["init"] = 1;
				include("modules/splash.php");
				die(getSplashScreen());
			}*/
		}

		public function getError() {
			return $this->error;
		}

		private function setError($str) {
			$this->error = $str;
			return false;
		}


		private function checkEnvironment() {
			if ( !defined('AUTH_SERVER') || AUTH_SERVER == '' )
				return $this->setError(__('Invalid server configuration'));

			if ( !defined('AUTH_TYPE') || !(AUTH_TYPE == 'NONE' || AUTH_TYPE == 'BASIC' || AUTH_TYPE == 'LOGIN') )
				return $this->setError(__('Invalid server configuration'));

			return true;
		}

		private function setParameters() {
			$host = AUTH_SERVER;
			$username = $password = '';
			switch(AUTH_TYPE) {
				case 'NONE':
					$username = AUTH_LOGIN;
					$password = AUTH_PASSWORD;
					break;
				case 'BASIC':
				case 'LOGIN':
					$username = Session::get('auth', 'user', true);
					$password = Session::get('auth', 'pwd', true);
					break;
			}

			define("DB_HOST", $host);
			define("DB_USER", $username);
			define("DB_PASS", $password);

			Session::set('auth', 'type', AUTH_TYPE);

			return true;
		}

		private function getAuthNone() {
			Session::set('auth', 'valid', true);
			$this->db->disconnect();
			header('Location: '.EXTERNAL_PATH);
			return true;	
		}

		private function getAuthBasic() {
			if (isset($_SERVER['PHP_AUTH_USER']) && isset($_SERVER['PHP_AUTH_PW'])) {
				if ($this->db->connect(AUTH_SERVER,$_SERVER['PHP_AUTH_USER'],$_SERVER['PHP_AUTH_PW']))	{
					Session::set('auth', 'valid', true);
					Session::set('auth', 'user', $_SERVER['PHP_AUTH_USER'], true);
					Session::set('auth', 'pwd', $_SERVER['PHP_AUTH_PW'], true);
					return true;
				} else
					$this->setError(__('Invalid Credentials'));
			}

			header('WWW-Authenticate: Basic realm="MyWebSQL"');
			header($_SERVER['SERVER_PROTOCOL'].' 401 Unauthorized');
			echo __('Invalid Credentials supplied');

			return false;
		}

		private function getAuthLogin() {
			if (isset($_POST['auth_user']) && isset($_POST['auth_pwd'])) {
				if ($this->db->connect(AUTH_SERVER, $_POST['auth_user'], $_POST['auth_pwd']))	{
					Session::set('auth', 'valid', true);
					Session::set('auth', 'user', $_POST['auth_user'], true);
					Session::set('auth', 'pwd', $_POST['auth_pwd'], true);
					$this->db->disconnect();
					header('Location: '.EXTERNAL_PATH);
					return true;
				} else
					$this->setError(__('Invalid Credentials'));
			}

			$form = view('auth', array( 'LOGINID' => htmlspecialchars(v($_POST['auth_user'])) ) );
			include("modules/splash.php");
			die(getSplashScreen($this->getError(), $form));
		}
		
		private function getAuthSecureLogin() {
			$user = "";
			$password = "";
			
			if (isset($_POST['mywebsql_auth'])) {
				require_once("lib/external/jcryption.php");
				$jCryption = new jCryption();
				$d = Session::get('auth_enc', 'd');
				$n = Session::get('auth_enc', 'n');
				$decoded = $jCryption->decrypt($_POST['mywebsql_auth'], $d["int"], $n["int"]);
				parse_str($decoded, $info);
				$user = v($info['auth_user']);
				$password = v($info['auth_pwd']);
				
				if ($this->db->connect(AUTH_SERVER, $user, $password)) {
					Session::del('auth_enc');
					Session::set('auth', 'valid', true);
					Session::set('auth', 'user', $user, true);
					Session::set('auth', 'pwd', $password, true);
					$this->db->disconnect();
					header('Location: '.EXTERNAL_PATH);
					return true;
				} else
					$this->setError('Invalid Credentials');
			}

			$form = view('auth', array( 'LOGINID' => htmlspecialchars($user) ) );
			include("modules/splash.php");
			die(getSplashScreen($this->getError(), $form));
		}
	}
?>