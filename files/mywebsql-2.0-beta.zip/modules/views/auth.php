<div class="auth">
	<div>
		<label><?php echo __('User ID'); ?>:</label><input type="text" name="auth_user" size="30" value="{{LOGINID}}"/>
	</div>
	<div>
		<label><?php echo __('Password'); ?>:</label><input type="password" name="auth_pwd" size="30" />
	</div>
	<div>
		<input type="submit" value="<?php echo __('Login'); ?>" />
	</div>
</div>
<script language="javascript" type="text/javascript">
document.dbform.auth_user.focus();
</script>