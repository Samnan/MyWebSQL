<?php

	/**********************************
	 *  config/lang.php               *
	 *  Supported language listings   *
	 **********************************/

	$_LANGUAGES = array (
		'en' => 'English',
		'af' => 'Afrikaans',
		'sq' => 'Albanian',
		'bg' => 'Bulgarian',
		'ca' => 'Catalan',
		'zh' => 'Chinese',
		'hr' => 'Croatian',
		'cs' => 'Czech',
		'da' => 'Danish',
		'nl' => 'Dutch',
		'es' => 'Spanish',
		'et' => 'Estonian',
		'fi' => 'Finnish',
		'fr' => 'French',
		'gl' => 'Galician',
		'ka' => 'Georgian',
		'de' => 'German',
		'el' => 'Greek',
		'he' => 'Hebrew',
		'hu' => 'Hungarian',
		'id' => 'Indonesian',
		'it' => 'Italian',
		'ja' => 'Japanese',
		'ko' => 'Korean',
		'lt' => 'Lithuanian',
		'lv' => 'Latvian',
		'ms' => 'Malay',
		'no' => 'Norwegian',
		'pl' => 'Polish',
		'pt' => 'Portuguese',
		'ro' => 'Romanian',
		'ru' => 'Russian',
		'sk' => 'Slovak',
		'sl' => 'Slovenian',
		'sr' => 'Serbian',
		'sv' => 'Swedish',
		'th' => 'Thai',
		'tr' => 'Turkish',
		'uk' => 'Ukrainian'
	);
	
	if (!defined('LANGUAGE')) {
		$_lang = 'en';
		if (isset($_GET["lang"]) && array_key_exists($_GET["lang"], $_LANGUAGES) && file_exists('lang/'.$_GET["lang"].'.php')) {
			$_lang = $_GET["lang"];
			setcookie("lang", $_GET["lang"], time()+(COOKIE_LIFETIME*60*60), EXTERNAL_PATH);
		}
		else if (isset($_COOKIE["lang"]) && array_key_exists($_COOKIE["lang"], $_LANGUAGES) && file_exists('lang/'.$_COOKIE["lang"].'.php'))
			$_lang = $_COOKIE["lang"];
			
		define("LANGUAGE", $_lang);	
	}
	
	

?>