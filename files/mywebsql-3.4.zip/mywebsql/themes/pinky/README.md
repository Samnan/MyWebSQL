MyWebSQL-Theme-pinky
====================

A pinkish coloured theme for MyWebSQL