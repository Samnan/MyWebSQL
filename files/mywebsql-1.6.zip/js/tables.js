/**********************************************************
 *  tables.js - Author: Samnan ur Rehman                  *
 *  This file is a part of MyWebSQL package               *
 *  collection of functions to help with                  *
 *  tables sorting/editing etc                            *
 **********************************************************/

var curEditField = null;         // current edited field
var curEditFieldId = null;       // id of the parent <tr> of edited field
var editData = new Array();      // whole of current editing data until saved or discarded
var fieldInfo = null;            // information about fields in record set
var editOptions = null;
var editToolbarTimer = null;     // timer for hiding editing toolbar during field editing

var selectedRow = -1;

// options can include
// highlight: boolean: highlights row on mouse over
// selectable: boolean: makes row selectable
// editable: boolean: makes grid editable
// sortable: boolean: makes table sorting possible using its header

function setupTable(id, opt) {
	opt.editEvent ? void(0) : opt.editEvent = 'dblclick';
	opt.editFunc ? void(0) : opt.editFunc = editTableCell;

	if (opt.sortable) {
		sorttable.DATE_RE = /^(\d\d?)[\/\.-](\d\d?)[\/\.-]((\d\d)?\d\d)$/;
		table = document.getElementById(id);
		sorttable.makeSortable(table);
	}

	if (opt.highlight) {
		$('#'+id+' tr').hover(function() {
			$(this).addClass("rowHL");
		}, function() {
			$(this).removeClass('rowHL');
		});
	}

	if (opt.selectable) {
		$('#'+id+' tr').bind('click', function() {
			if (selectedRow != null)
				$(selectedRow).removeClass('rowSel');
			$(this).addClass("rowSel");
			selectedRow = this;
		});
	}

	editOptions = null;
	if (opt.editable) {
		editOptions = opt;
		$('#'+id+' td.edit').bind(opt.editEvent, opt.editFunc);
	}
}

function editTableCell() {
	// avoid flickers in showing/hiding toolbar when navigating between result set fields
	if (editToolbarTimer) {
		window.clearTimeout(editToolbarTimer);
		editToolbarTimer = null;
	}

	td = $(this);
	if (curEditField != null)
		closeEditor(true);

	//txt = td.text();
	isBlob = td.find('span.data').length;
	txt =  isBlob ? td.find('span.data').text() : td.text();
	tstyle = td.hasClass('tr') ? "right" : "left";

	td.data('defText', txt);

	curEditField = this;
	curEditFieldId = this.parentNode.id.substr(2);
	fid = str_replace("r" + curEditFieldId + "f", "", curEditField.id);
	fi = getFieldInfo(fid);
	w = td.width() - (isBlob ? 22 : 0);
	h = td.height();
	td.attr('width', w);
	p = Position.get(this);

	input = createCellEditor(td, fi, txt, w, h, tstyle);

	// this is needed for IE
	setTimeout( function() { input.focus(); }, 50 );

	if (document.getElementById('editToolbar')) {
		leftPos = p.left;
		tbHeight = $('#editToolbar').height();
		if (leftPos + $('#editToolbar').width() >= document.body.clientWidth)
			leftPos = document.body.clientWidth - $('#editToolbar').width() - 20;   // keep some space off as there maybe scrollbars
		$('#editToolbar').css({"display":"block", "left":leftPos + "px","top":(p.top-tbHeight-12) + "px"});
	}
}

function closeEditor(upd, value) {
	if (!curEditField)
		return;
	
	txt = '';
	if (upd) {
		var xt = new Object();
		if (arguments.length > 1 && value == null) {
			xt.value = "NULL";
			xt.setNull = true;
		}
		else {
			txt = xt.value = $(curEditField).find('input').val();
			xt.setNull = false;
		}

		// if not modified, don't bother
		if ( (xt.value != $(curEditField).data('defText')) || (xt.setNull && !$(curEditField).hasClass("tnl"))
				|| (!xt.setNull && $(curEditField).hasClass('tnl')) ) {
			if (typeof editData[curEditFieldId] != "object")
				editData[curEditFieldId] = new Array();

			fid = str_replace("r" + curEditFieldId + "f", "", curEditField.id);
			editData[curEditFieldId][fid] = xt;

			if (typeof showNavBtn == "function")
				showNavBtn('update', 'gensql');

			if(xt.setNull)
				$(curEditField).removeClass('tl').addClass('tnl');
			else
				$(curEditField).removeClass('tnl').addClass('tl');

			txt = xt.value;
			//txt = str_replace("<", "&lt;", xt.value);
			//txt = str_replace(">", "&gt;", txt);
		}
	}
	else
		txt = $(curEditField).data('defText');

	if ($(curEditField).find('span.data').length)	// for blobs this is true
		$(curEditField).find('span.data').text(txt);
	else
		$(curEditField).text(txt);
	$(curEditField).removeAttr('width');
	curEditField = null;

	if (document.getElementById('editToolbar'))
		editToolbarTimer = window.setTimeout(function() { document.getElementById('editToolbar').style.display = "none"; editToolbarTimer=null; }, 100 );
}

function checkEditField(event) {
	// enter, tab, up arrow, down arrow
	keys = [13,9,38,40];
	if (keys.indexOf(event.keyCode) != -1) {
		event.preventDefault();
		elem = false;
		if (event.keyCode == 9) {
			elem = event.shiftKey ? $(curEditField).prev('.edit') : $(curEditField).next('.edit');
			if (!elem.length) {  // move to next/previous record if possible
				tr = event.shiftKey ? $(curEditField).parent().prev() : $(curEditField).parent().next();
				if (tr.length)
					elem = event.shiftKey ? tr.find('td:last') : tr.find('td.edit:first');
			}
		} else if (event.keyCode == 38 || event.keyCode == 40) {
			tr = event.keyCode == 38 ? $(curEditField).parent().prev() : $(curEditField).parent().next();
			if (tr.length)
				elem = tr.find('td').eq($(curEditField).index());
		}
		closeEditor(true);
		if (elem && elem.length)    // edit next or previous element
			elem.trigger(editOptions.editEvent);
	}
	else if (event.keyCode == 27)
		closeEditor(false);
	else if ($(this).attr('readonly') != '' && [16,17,18].indexOf(event.keyCode) == -1 ) {
	   // focus is on a blob editor, need to open dialog for any keypress
		oldEditField = curEditField;
		closeEditor(false);
		$(oldEditField).find('span.blob').click();
	}
}

function createCellEditor(td, fi, txt, w, h, align) {
	keyEvent = 'keydown';
	code = '<form name="cell_editor_form" class="cell_editor_form" action="javascript:void(0);">';
	if (fi['blob'] == 1) {
		code += '<input type="text" readonly="readonly" name="cell_editor" class="cell_editor" style="text-align:' + align + ';width: ' + w + 'px;" />';
		code += '</form>';
		td.find('span.data').html(code);
		input = td.find('input');
		input.val(txt).bind(keyEvent, checkEditField ).blur( function() {closeEditor(true)} );
	}
	else {
		switch(fi['type']) {
			default:
				code += '<input type="text" name="cell_editor" class="cell_editor" style="text-align:' + align + ';width: ' + w + 'px;" />';
				code += '</form>';
				td.html(code);
				input = td.find('input');
				input.val(txt).select().bind(keyEvent, checkEditField ).blur( function() {closeEditor(true)} );
				break;
		}
	}
	return input;
}