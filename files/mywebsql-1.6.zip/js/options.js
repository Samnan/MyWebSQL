/************************************************
 *	options.js - Author: Samnan ur Rehman        *
 * contains top level menu commands used in js  *
 * depends on query.js for utility commands     *
 *	This file is a part of MyWebSQL package      *
 ************************************************/

function logout() {
	optionsConfirm("Are you sure you want to logout?", 'sess.logout', function(result, id, confirm_always) {
		if (result)
		{
			if (confirm_always) optionsConfirmSave(id);
			wrkfrmSubmit("logout", '', '', '');
		}
	});
}

/* ------------------------------- */
function dbSelect() {
	db = (arguments.length == 1) ? "?db=" + arguments[0] : "?db=" + document.getElementById("dblist").options[document.getElementById("dblist").selectedIndex].text;
	window.location.href = db;
}

function dbDrop(name) {
	optionsConfirm("Are you sure you want to DROP the database <b>"+name+"</b>?", 'db.drop', function(result, id, confirm_always) {
		if (result)
		{
			if (confirm_always) optionsConfirmSave(id);
				wrkfrmSubmit("dbdrop", type, name);
		}
	});
}

function dbEmpty(name) {
	optionsConfirm("Are you sure you want to DROP all objects from the database <b>"+name+"</b>?", 'db.empty', function(result, id, confirm_always) {
		if (result)
		{
			if (confirm_always) optionsConfirmSave(id);
				wrkfrmSubmit("dbempty", type, name);
		}
	});
}

function dbRefresh() {
	window.location = window.location;
}

function dbCreate(submit) {
	if (arguments.length && submit)
	{
		name = $.trim($('#dbname').val());
		if (name != '')
		{
			wrkfrmSubmit("dbcreate", "", name, $('#dbselect').attr('checked') ? '1' : '0');
			$("#dialog-dbcreate").dialog('close');
			return false;
		}
	}
	else
	{
		$('#dbname').val('');
		$('#dbselect').attr('checked', false);
		$('#dialog-dbcreate').dialog('open');
	}
}

/* ------------------------------- */
function objDefault(item, id) {
	$(currentTreeItem).removeClass('current');
	currentTreeItem = $('#t_'+str_replace(' ', '_', id));
	currentTreeItem.addClass('current').find('a').blur();
	wrkfrmSubmit("showinfo", item, id, "");
}


function objCreate(id) {
	openPopupDiv("?q=wrkfrm&type=objcreate&id="+id, 535, 430);
}

function objTruncate(type, name) {
	optionsConfirm("Are you sure you want to empty the table?", 'obj.truncate', function(result, id, confirm_always) {
		if (result)
		{
			if (confirm_always) optionsConfirmSave(id);
				wrkfrmSubmit("truncate", type, name);
		}
	});
}
function objDrop(type, name) {
	optionsConfirm("Are you sure you want to drop this object?", '', function(result, id, confirm_always) {
		if (result)
				wrkfrmSubmit("drop", type, name);
	});
}
function objRename(type, name) {
	jPrompt('Enter new name for the database object', name, 'Rename Object',function(new_name) {
		if (new_name == null)
			return;
		else if (new_name && new_name != name)
			wrkfrmSubmit("rename", type, name, new_name);
		else
			jAlert('New name missing or unchanged');
	});
}

/* ------------------------------- */
function tableCreate() {
	openPopupDiv("?q=wrkfrm&type=createtbl", 780, 440, true);
}

function tableSelect(name)
{
	st = sql_delimiter + "select * from `" + name + "`";
	setSqlCode( st, 1 );
}
function tableInsert(name) { wrkfrmSubmit("tableinsert", "", name); }
function tableUpdate(name) { wrkfrmSubmit("tableupdate", "", name); }
function tableDescribe(name) { wrkfrmSubmit("query", "", "", "describe `" + name + "`"); }
function tableViewData(name) {
	q = "select * from `" + name + "`";
	setSqlCode(sql_delimiter + q, 1);
	wrkfrmSubmit("query", "table", "", name);
}

function tableAlter(name) { openPopupDiv("?q=wrkfrm&type=altertbl&name="+escape(name), 780, 440, true); }
function showCreateCmd(type, name) {	wrkfrmSubmit("showcreate", type, name, ""); }

/* ------------------------------- */
function dataImport() {
	openPopupDiv("?q=wrkfrm&type=import", 610, 360);
}

function resultsExport() {
	if (numRecords == 0)
		jAlert("There is no record in the results to export.", "Exports results");
	else
		openPopupDiv("?q=wrkfrm&type=exportres", 400, 290);
}

function dataExport() {
	openPopupDiv("?q=wrkfrm&type=export", 600, 420);
}

function tableExport(tbl) {
	openPopupDiv("?q=wrkfrm&type=exporttbl&table="+tbl, 400, 280);
}

function exportData() {
	id = arguments.length > 0 ? arguments[0] : '';
	name = arguments.length > 1 ? arguments[1] : '';
	query = arguments.length > 2 ? arguments[2] : '';
	wrkfrmSubmit('dl', 'export'+id, name, query);
}

/* ------------------------------- */
function helpShowAll() { openPopupDiv("?q=wrkfrm&type=help", 680, 440); }
function helpQuickTutorial() {
	$('<link>').appendTo('head').attr({ rel:  "stylesheet", type: "text/css", href: "img/ehelp.css" });
	$.getScript('cache.php?script=ehelp', function() {
		showEHelp();
	});
}
function helpOnlineDocs() { window.open('http://mywebsql.net/docs'); }
function helpReportBug() {	window.open('https://sourceforge.net/tracker/?func=add&group_id=242139&atid=1118363'); }
function helpRequestFeature() { window.open('http://sourceforge.net/tracker/?func=add&group_id=242139&atid=1118366'); }

function interfaceTheme(t) {
	data = 'theme='+escape(t);
	$.ajax({ type: 'GET',
		url: '?',
		data: data,
		success: function(res) { window.location = window.location; },
		dataType: 'html'
	});
}

/* ------------------------------- */
function toolsOptions() {
	openPopupDiv("?q=wrkfrm&type=options", 500, 260);
}

function toolsProcManager() {
	openPopupDiv("?q=wrkfrm&type=processes", 560, 380);
}

function infoDefault() {
	wrkfrmSubmit("info", "", "", "");
}

function infoServer() {
	wrkfrmSubmit("infoserver", "", "", "");
}

function infoVariables() {
	wrkfrmSubmit("infovars", "", "", "");
}

function infoDatabase() {
	wrkfrmSubmit("infodb", "", "", "");
}

/* ------------------------------- */
function copyText(t) {
}

function copyColumn(t) {
}

function sqlFilterText(t) {
}

/* ------------------------------- */