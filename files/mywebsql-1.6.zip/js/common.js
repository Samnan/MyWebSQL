/**********************************************
 *	common.js - Author: Samnan ur Rehman       *
 *	This file is a part of MyWebSQL package    *
 **********************************************/

function wrkfrmSubmit(type, id, name, query) {
	if (!document.frmquery) {
		if ($.browser.msie)
			xfrm = document.frames("wrkfrm");
		else
			xfrm = window.frames["wrkfrm"];

		frm = xfrm.document.frmquery;
		xfrm.onerror = frameErrorHandler;
		setPageStatus(true);
	}
	else	// function called from an iframe in the popup
		frm = document.frmquery;

	frm.type.value = type;
	frm.id.value = id;
	frm.name.value = name;
	frm.query.value = query;
	
	if (arguments.length <= 4)
		frm.submit();
	else {
		callback = arguments[4];
		data = 'q=wrkfrm&' + $(frm).serialize();
		$.ajax({ type: 'POST',
			url: '?',
			data: data,
			success: callback
		});
	}
}

function resetFrame() {
	if ($.browser.msie)
		xfrm = document.frames("wrkfrm");
	else
		xfrm = window.frames["wrkfrm"];

	xfrm.src = "javascript:false";
}

function debugMsg(msg) {
	$('#messageContainer').innerHTML = msg;
}

function frameErrorHandler() {
	setPageStatus(false);
	$('#recordCounter').html('&nbsp;');
	$('#timeCounter').html('');
	$('#messageContainer').html('Navigation Error. Try reloading the page');
}

function setPageStatus(flg, msg) {
	if (flg) {
		$('#nav_bar').css('display', 'none');
		$('#loader').css('display', 'table');
		showNavBtns();		// hide all buttons
	}
	else {
		$('#loader').css('display', 'none');
		$('#nav_bar').css('display', 'table');
		showNavBtns('query', 'queryall');
	}

	if (msg)
		$('#messageContainer').html(msg);
}

function openPopupDiv(url, w, h) {
	$("#dialog_contents").attr("src", 'javascript:false');
	updatePopup(0);
	$('#dialog').dialog('option', 'width', w);
	$('#dialog').dialog('option', 'height', h);
	//$('#dialog').dialog('option', 'modal', arguments.length>3 && arguments[3] ? false : true);
	$('#dialog').dialog('open');
	$("#ui-dialog-title-dialog").html('Loading ...');
	$("#dialog_contents").attr("src", url);
}

function updatePopup(n) {
	if (n == 1) {
		$("#dialog_msg").css("display", "none");
		$("#dialog_contents").css("display", "block");
		$('.ui-dialog').trigger('resize');
	} else {
		$("#dialog_msg").css("display", "block");
		$("#dialog_contents").css("display", "none");
	}
}

function updatePopupTitle(s) {
	$("#ui-dialog-title-dialog").html(s);
}

function __parseBorderWidth(width) {
	var res = 0;
	if (typeof(width) == "string" && width != null && width != "" ) {
		var p = width.indexOf("px");
		if (p >= 0) {
			res = parseInt(width.substring(0, p));
		}
		else {
			//do not know how to calculate other values (such as 0.5em or 0.1cm) correctly now
			//so just set the width to 1 pixel
			res = 1;
		}
	}
	return res;
}

//returns border width for some element
function __getBorderWidth(element) {
	var res = new Object();
	res.left = 0; res.top = 0; res.right = 0; res.bottom = 0;
	if (window.getComputedStyle) {
		//for Firefox
		var elStyle = window.getComputedStyle(element, null);
		res.left = parseInt(elStyle.borderLeftWidth.slice(0, -2));
		res.top = parseInt(elStyle.borderTopWidth.slice(0, -2));
		res.right = parseInt(elStyle.borderRightWidth.slice(0, -2));
		res.bottom = parseInt(elStyle.borderBottomWidth.slice(0, -2));
	}
	else {
		//for other browsers
		res.left = __parseBorderWidth(element.style.borderLeftWidth);
		res.top = __parseBorderWidth(element.style.borderTopWidth);
		res.right = __parseBorderWidth(element.style.borderRightWidth);
		res.bottom = __parseBorderWidth(element.style.borderBottomWidth);
	}

	return res;
}

//returns absolute position of some element within document
function getAbsolutePos(element) {
    var res = new Object();
    res.x = 0; res.y = 0;
    if (element !== null) {
        res.x = element.offsetLeft;
        res.y = element.offsetTop;

        var offsetParent = element.offsetParent;
        var parentNode = element.parentNode;
        var borderWidth = null;

        while (offsetParent != null) {
            res.x += offsetParent.offsetLeft;
            res.y += offsetParent.offsetTop;

            var parentTagName = offsetParent.tagName.toLowerCase();

            if (($.browser.msie && parentTagName != "table") ||
                ($.browser.mozilla && parentTagName == "td")) {
                borderWidth = __getBorderWidth(offsetParent);
                res.x += borderWidth.left;
                res.y += borderWidth.top;
            }

            if (offsetParent != document.body &&
                offsetParent != document.documentElement) {
                res.x -= offsetParent.scrollLeft;
                res.y -= offsetParent.scrollTop;
            }

            //next lines are necessary to support FireFox problem with offsetParent
               if (!$.browser.msie) {
                while (offsetParent != parentNode && parentNode !== null) {
                    res.x -= parentNode.scrollLeft;
                    res.y -= parentNode.scrollTop;
                    parentNode = parentNode.parentNode;
                }
            }

				parentNode = offsetParent.parentNode;
				offsetParent = offsetParent.offsetParent;
        }
    }
    return res;
}

function addCmdHistory(str) {
	d = new Date();
	h = d.getHours();
	m = d.getMinutes();
	if (h < 10) h = '0'+h;
	if (m < 10) m = '0'+m;
	$('#sql-history > tbody:last').append("<tr><td valign=\"top\" class=\"dt\">[" + h + ":" + m + "]</td><td class=\"hst\">" + str + ";</td></tr>");

	if (arguments.length > 1 && arguments[1] == true)
		currentQuery = str;
}

function str_replace(search, replace, subject) {
	var f = search, r = replace, s = "" + subject;
	var ra = is_array(r), sa = is_array(s), f = [].concat(f), r = [].concat(r), i = (s = [].concat(s)).length;

	while (j = 0, i--) {
		while (s[i] = s[i].split(f[j]).join(ra ? r[j] || "" : r[0]), ++j in f){};
	};

	return sa ? s : s[0];
}

function is_array( mixed_var ) {
	return ( mixed_var instanceof Array );
}

/* simple hack for IE :P */
if(!Array.indexOf) {
	Array.prototype.indexOf = function(obj) {
		for(var i=0; i<this.length; i++) {
			if(this[i]==obj){
				return i;
			}
		}
		return -1;
	}
}
