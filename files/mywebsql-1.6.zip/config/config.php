<?php

	/****************************************
	 * Change the setting below if you like *
	 ****************************************/

	define("TRACE_MESSAGES", FALSE);        // logs verbose stuff in the error log file (only enable for debugging)
	define("TRACE_FILEPATH", "");           // if logs are to be directed to a separate file other than the default
	define("LOG_MESSAGES", FALSE);          // enabling this will send 'critical' messages to the default log file (including failed queries)
	define("MAX_RECORD_TO_DISPLAY", 100);   // only this much records will be shown in browser at one time to keep it responsive
	define("MAX_BLOB_LENGTH_CHECK", 80);    // blobs/text size larger than this is truncated in grid view format
	define("MAX_BINARY_LENGTH_CHECK", 20);  // binary data size larger than this is truncated in grid view format
	define("SQL_EDITORTYPE", "codemirror"); // valid values are [textarea|codemirror], defaults to codemirror
	define("USE_MYSQLI", 1);                // if defined and set to 1, mysqli will be used (if extension is not loaded, this will be ignored)
	define("HOTKEYS_ENABLED", TRUE);        // enable hotkeys
	if(!defined('THEME_PATH'))
		define('THEME_PATH', 'default');     // use this theme as default when user has not selected any theme
	
	/****************************************
	 * You should not change anything below *
	 *  Unless you know what you are doing  *
	 ****************************************/

	include(dirname(__FILE__)."/constants.php");
	include(dirname(__FILE__)."/auth.php");
	include(dirname(__FILE__)."/keys.php");

?>