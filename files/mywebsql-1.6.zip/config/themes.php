<?php

	/****************************************
	 *  themes.php                          *
	 *  Theme listing configuration file    *
	 ****************************************/

	$THEMES = array(
		"default" => "Default",
		"light" => "Light (Gray)",
		"dark" => "Dark"
		//"human" => "Humanity (Ubuntu style)"
		//"blitzer" => "Blitzer",
		//"sunny" => "Sunny"
		);

	if (!defined('THEME_LOADED'))
	{
		if (isset($_GET["theme"]) && array_key_exists($_GET["theme"], $THEMES))
		{
			define("THEME_PATH", $_GET["theme"]);
			setcookie("theme", $_GET["theme"], time()+(60000), "/");
		}
		else if (isset($_COOKIE["theme"]) && array_key_exists($_COOKIE["theme"], $THEMES))
			define("THEME_PATH", $_COOKIE["theme"]);
			
		define('THEME_LOADED', '1');
	}
?>