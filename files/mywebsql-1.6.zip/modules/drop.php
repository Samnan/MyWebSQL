<?php

	/***********************************************
	*  drop.php - Author: Samnan ur Rehman         *
	*  This file is a part of MyWebSQL package     *
	*  PHP5 compatible                             *
	***********************************************/

	function processRequest(&$db)
	{
		$type = v($_REQUEST["id"]);
		$name = v($_REQUEST["name"]);
		
		if (!$name)
		{
			createErrorGrid($db, '');
			return;
		}
		
		$query = 'drop '.$db->escape($type).' `'.$db->escape($name).'`';
		if ($db->query($query)) {
			Session::set('db', 'altered', true);
			createInfoGrid($db, $query);
		}
		else
			createErrorGrid($db, $query);
	}
?>