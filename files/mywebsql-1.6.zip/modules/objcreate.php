<?php

	/********************************************************************
	*	objectcreate.php - Author: Samnan ur Rehman						*
	*	This file is a part of MyWebSQL package							*
	*	PHP5 compatible													*
	*********************************************************************/

	function processRequest(&$db)
	{
		$type = "note";
		if (isset($_REQUEST["objinfo"]))
		{
			$msg = createDatabaseObject($db, $_REQUEST["id"], $_REQUEST["objinfo"]);
			if (!$msg)		// msg will be returned only if error (bad programming guys, dont learn from it !)
			{
				$msg = "The command executed successfully.";
				$type = "success";
			}
			else
				$type="warning";
		}
		else
			$msg = "Any existing object with the same name should be dropped manually before executing the creation command !";
			displayCreateObjectForm($msg, $type);
	}

	function displayCreateObjectForm($msg, $type="warning")
	{
		$id = $_REQUEST["id"];
		if (isset($_REQUEST["objinfo"]))
			$objInfo = htmlspecialchars($_REQUEST["objinfo"]);
		else
			$objInfo = getObjectCreateCommand($id);
		print "</textarea></td></tr>";

		$min = file_exists('js/min/minify.txt');
		$js = $min ? 'codemirror' : 'editor/codemirror';
		$editor_link = "<script type=\"text/javascript\" language=\"javascript\" src=\"cache.php?script=$js\"></script><script type=\"text/javascript\" language=\"javascript\">";
		$editor_options = $min ? 'basefiles: ["js/min/codemirror_base.js"]' : 'parserfile: "mysql.js", path: "js/editor/"';

		$replace = array('ID' => htmlspecialchars($id),
								'MESSAGE' => $msg,
								'MESSAGE_TYPE' => $type,
								'OBJINFO' => $objInfo,
								'EDITOR_LINK' => $editor_link,
								'EDITOR_OPTIONS' => $editor_options
							);

		echo view('objcreate', $replace);
	}

	function getObjectCreateCommand($id)
	{
		if ($id == 0)
			$x = "CREATE TABLE table_name (
	 field_1 INT(10) NOT NULL,
	 field_2 VARCHAR(20),
	 field_3 DATETIME,
	 field_4 TEXT,
	 field_5 BLOB
)
[TYPE= {MYISAM | INNODB}]";
		else if ($id == 1)
			$x = "
CREATE
    /*[ALGORITHM = {UNDEFINED | MERGE | TEMPTABLE}]
    [DEFINER = { user | CURRENT_USER }]
    [SQL SECURITY { DEFINER | INVOKER }]*/
    VIEW `new_view_1`
    AS
    (SELECT * FROM ...)";
		else if ($id == 2)
			$x = "CREATE
    /*[DEFINER = { user | CURRENT_USER }]*/
    PROCEDURE `new_proc_1` ()
    /*LANGUAGE SQL
    | [NOT] DETERMINISTIC
    | { CONTAINS SQL | NO SQL | READS SQL DATA | MODIFIES SQL DATA }
    | SQL SECURITY { DEFINER | INVOKER }
    | COMMENT 'string'*/
    BEGIN

    END";
		else if ($id == 3)
			$x = "
CREATE
    /*[DEFINER = { user | CURRENT_USER }]*/
    FUNCTION `new_func_1` ()
    RETURNS type
    /*LANGUAGE SQL
    | [NOT] DETERMINISTIC
    | { CONTAINS SQL | NO SQL | READS SQL DATA | MODIFIES SQL DATA }
    | SQL SECURITY { DEFINER | INVOKER }
    | COMMENT 'string'*/
    BEGIN

    END";
		else if ($id == 4)
		$x = "
CREATE
    /*[DEFINER = { user | CURRENT_USER }]*/
    TRIGGER `new_trig_1` BEFORE/AFTER INSERT/UPDATE/DELETE
    ON `<table>`
    FOR EACH ROW BEGIN

    END";
		return htmlspecialchars($x);
	}

	function createDatabaseObject(&$db, $id, $info)
	{
		$cmd = trim($info);
		if (strtolower(substr($cmd, 0, 6)) != "create")
			return "Only create commands are accepted";

		if (!$db->query($cmd))
			return htmlspecialchars($db->getError());

		return "";
	}


?>