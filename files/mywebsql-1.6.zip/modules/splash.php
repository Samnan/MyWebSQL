<?php

	/***************************************************************
	*	splash.php - Author: Samnan ur Rehman                       *
	*	This file is a part of MyWebSQL package                     *
	*	Used for displaying the startup screen for the program      *
	*	PHP5 compatible                                             *
	***************************************************************/

	function getSplashScreen($msg = '', $formCode='')
	{
		if ($formCode)
		{
			$formCode = '<div class="login"><form method="post" action="#" name="dbform" style="text-align:center">'
							. $formCode . '</form>';
		}

		$replace = array(
			'MESSAGE' => $msg ? '<div class="msg">'.htmlspecialchars($msg).'</div>' : '',
			'FORM'    => $formCode,
			'APP_VERSION'  => APP_VERSION,
			'PROJECT_SITEURL' => PROJECT_SITEURL
			);

		return view('splash', $replace);
	}
?>