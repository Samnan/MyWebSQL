	<div class="heading">Miscellaneous</div>
		<ul>
			<li>MyWebSql is primarily designed for working with small result sets.</li>
			<li>Queries are modified slightly on server to return <i>only first <b>100</b> records</i>, which is sufficient enough for a daily basis developer work. <br/>(<b>This can be changed by modifying configuration file</b>)</li>
			<li>Please do submit your suggestions and bug reports. They help us improve !</li>
		</ul>
	</div>