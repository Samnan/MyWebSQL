<!--<div style='float:left;margin-left:10px' id="blobedit_buttons">
	<a id="btnEditBlob" class="btn" href="javascript:blobEdit()">Edit</a>
	<a id="btnSaveBlob" class="btn" href="javascript:blobSave()">Save</a>
	{{MESSAGE}}
</div>
-->