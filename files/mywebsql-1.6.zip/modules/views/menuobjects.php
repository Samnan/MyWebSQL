<div style="display:none">

<div id="db-menu">
	<ul class="dropdown context">
		<li><a href="javascript:dbSelect([name])" title="Use this database">Use Database</a></li>
		<!--li><a href="javascript:dbDrop([name])" title="Drop this database">Drop Database</a></li>
		<li><a href="javascript:dbEmpty([name])" title="Drop all tables from this database">Empty Database</a></li-->
	</ul>
</div>

<div id="table-menu">
<ul class="dropdown context">
	<li><a href="tableSelect([name])">Select statement</a></li>
	<li><a href="tableInsert([name])">Insert statement</a></li>
	<li><a href="tableUpdate([name])">Update statement</a></li>
	<li><a href="tableDescribe([name])">Describe</a></li>
	<li><a href="showCreateCmd('table', [name])">Show create command</a></li>
	<li><a href="tableViewData([name])">View data</a></li>
	<li><a href="javascript:void(0)">More operations</a>
		<ul>
			<li><a href="tableAlter([name])">Alter Table</a></li>
			<li><a href="objTruncate('table', [name])">Truncate</a></li>
			<li><a href="objDrop('table', [name])">Drop</a></li>
			<li><a href="objRename('table', [name])">Rename</a></li>
		</ul>
	</li>
	<li class="separator">-------------------------------------------------------</li>
	<li><a href="tableExport([name])">Export table data...</a></li>
	<li><a href="tableCreate()">Create Table...</a></li>
</ul>
</div>

<div id="view-menu">
<ul class="dropdown context">
	<li><a href="tableSelect([name])">Select statement</a></li>
	<li><a href="tableDescribe([name])">Describe</a></li>
	<li><a href="showCreateCmd('view', [name])">Show create command</a></li>
	<li><a href="tableViewData([name])">View data</a></li>
	<li><a href="objCreate(1)">Create View...</a></li>
	<li><a href="javascript:void(0)">More operations</a>
		<ul>
			<li><a href="objDrop('view', [name])">Drop</a></li>
			<li><a href="objRename('view', [name])">Rename</a></li>
		</ul>
	</li>
</ul>
</div>

<div id="proc-menu">
<ul class="dropdown context">
	<li><a href="showCreateCmd('procedure', [name])">Show create command</a></li>
	<li><a href="objCreate(2)">Create Procedure...</a></li>
	<li><a href="javascript:void(0)">More operations</a>
		<ul>
			<li><a href="objDrop('procedure', [name])">Drop</a></li>
			<li><a href="objRename('procedure', [name])">Rename</a></li>
		</ul>
	</li>
</ul>
</div>

<div id="func-menu">
<ul class="dropdown context">
	<li><a href="showCreateCmd('function', [name])">Show create command</a></li>
	<li><a href="objCreate(3)">Create Function...</a></li>
	<li><a href="javascript:void(0)">More operations</a>
		<ul>
			<li><a href="objDrop('function', [name])">Drop</a></li>
			<li><a href="objRename('function', [name])">Rename</a></li>
		</ul>
	</li>
</ul>
</div>

<div id="trig-menu">
<ul class="dropdown context">
	<li><a href="showCreateCmd('trigger', [name])">Show create command</a></li>
	<li><a href="objCreate(4)">Create Trigger...</a></li>
	<li><a href="javascript:void(0)">More operations</a>
		<ul>
			<li><a href="objDrop('trigger', [name])">Drop</a></li>
			<!--li><a href="objRename('trigger', [name])">Rename</a></li-->
		</ul>
	</li>
</ul>
</div>

<div id="panel-menu-objects">
<ul class="dropdown context">
	<li><a href="main_layout.toggle('west')">Show/Hide Panel</a></li>
</ul>
</div>

<div id="panel-menu-editor">
<ul class="dropdown context">
	<li><a href="data_layout.toggle('south')">Show/Hide Panel</a></li>
</ul>
</div>

<div id="history-menu">
<ul class="dropdown context">
	<li><a href="javascript:historyCopy($(this))" title="Copy all queries to clipboard">Copy to clipboard</a></li>
	<li><a href="javascript:historyClear($(this))" title="Clear all queries from history">Clear history</a></li>
</ul>
</div>

<div id="data-menu-th">
<ul class="dropdown context">
	<li><a href="copyColumn([name])">Copy Column values...</a></li>
</ul>
</div>

<div id="data-menu-td">
<ul class="dropdown context">
	<li><a href="copyText([name])">Copy to clipboard</a></li>
	<li><a href="sqlFilterText([name])">Generate SQL Filter</a></li>
</ul>
</div>

</div>