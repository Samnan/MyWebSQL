<script type="text/javascript" language="javascript" src="cache.php?script=jquery"></script>
<link href="cache.php?css=theme,default" rel="stylesheet" />

	<input type='hidden' name='q' value="wrkfrm" />
	<input type='hidden' name='type' value="objcreate" />
	<input type='hidden' name='id' value="{{ID}}" />
	<table border="0" cellspacing="6" cellpadding="2" width="100%">
	<tr><td>
			<div class="{{MESSAGE_TYPE}}">{{MESSAGE}}</div>
	</td></tr>
	<tr><td colspan="2">Enter command for object creation</td></tr>
	<tr><td colspan="2" align="right">
	<div class="code_editor">
	<textarea cols="86" rows="16" name="objinfo" id="objinfo" class='textEditor' style="height:250px;width:505px">{{OBJINFO}}</textarea>
	</div>
	</td></tr>
	<tr><td colspan="2" align="right">
		<input type='submit' name='btn' value='   Submit   ' onclick="submit_form()" />
	</td></tr>
	</table>

{{EDITOR_LINK}}
var code_editor = null;
$(function() {
	parent.updatePopupTitle('Create new database object');
	document.frmquery.objinfo.focus();
	code_editor = CodeMirror.fromTextArea('objinfo', { {{EDITOR_OPTIONS}},
		height: '250px', tabMode : 'default',
		stylesheet: 'cache.php?css=mysqlcolors', onLoad : function() { }
	});
});

function submit_form()
{
	if(code_editor)
		document.frmquery.objinfo.value = code_editor.getCode();
	document.frmquery.submit();
}
</script>


