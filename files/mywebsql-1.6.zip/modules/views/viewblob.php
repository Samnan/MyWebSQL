<link href="cache.php?css=default" rel="stylesheet" />
<script type="text/javascript" language="javascript" src="cache.php?script=jquery,blobs"></script>

	<table border="0" cellspacing="6" cellpadding="2" width="590px">
	<tr><td colspan="2">
		<div id="blobedit_toolbar">
			{{BLOB_TOOLBAR}}
			<div style='float:right;margin-right:20px' id="blob_options">
				Show blob data as:&nbsp;&nbsp;
				<select name='blobtype' onchange="blobChangeType()">
				{{BLOBOPTIONS}}
				</select>
			</div>
		</div>
	</td></tr>
	<tr><td colspan="2" align="right">
		<div style='overflow:auto;width:580px;height:400px'>
			<pre class='blob' id="blobdata">{{BLOBDATA}}</pre>
		</div>
	</td></tr>
	</table>
<input type="hidden" name="act" value="" />
<input type="hidden" name="blob_value" value="" />
<script type="text/javascript" language='javascript'>
	document.frmquery.type.value = 'viewblob';
	document.frmquery.id.value = '{{ID}}';
	document.frmquery.name.value = '{{NAME}}';
	document.frmquery.query.value = '{{QCODE}}';
	parent.updatePopupTitle('Blob/Text data for column {{NAME}}');
	var table = "{{TABLE}}";
	if (table == '')
		$('#blobedit_buttons').hide();
	else
		$('#btnSaveBlob').hide();
</script>