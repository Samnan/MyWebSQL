<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8;" />
<title>MyWebSql</title>
<link rel="SHORTCUT ICON" href="favicon.ico" />
<style>
* {
	font-family: Tahoma;
	font-size: 8pt;
	font-weight: normal;
	margin: 0;
	padding: 0;
	text-align: left;
}
label {
	display: inline-block;
	margin: 0 5px 0 5px;
	vertical-align: baseline;
}
input {
	padding: 3px;
}
input[type="text"], input[type="password"] {
	width: 190px;
}
input[type="button"], input[type="submit"] {
	min-width: 100px;
	text-align: center;
}
div.auth {
	width: 320px;
	margin: 0 auto;
	text-align: center;
	background: #f6f6f6;
	border: 4px double #DCDCDC;
	padding: 4px;
}
div.auth div {
	text-align: center;
	padding: 4px;
}
div.auth label {
	width: 100px;
	display: inline-block;
}

div.login {
	margin-left: 20%;
	margin-right: 20%;
	margin-top: 10px;
	width: 60%;
	font-family: verdana;
	font-size: 9pt;
	text-align: center;
}
div.msg {
	width:300px;
	padding: 4px;
	margin: 10px auto;
	background-color:pink;
	color;black;
	font-weight:bold;
	text-align:center
}
dl.splash         { position: relative; margin: 1em 0; display:inline-block; width: 257px; margin: 0 auto}
dl.splash dt img  { display: block; }
dl.splash dd      { position: absolute; left: 125px; bottom: 122px; font: bold 2em/1.25em Helvetica, sans-serif; }
dl.splash.top dd  { top: 1.25em; }
dl.splash dd span {
	display: block; float: left; clear: both;
	padding: 0.25em 0.5em; color: #fff;
	font: bold 8pt Tahoma, sans-serif;
	color: #da00b3;
}
</style>
</head>
<body style="background-color:white">
<div style="border:none;position:absolute;left:0px;top:0px;width:100%;height:100%;background-color:white;display:block;">
	<table border="0" width="100%" style="height:100%">
		<tr><td height="100%" valign="middle" align="center" style="text-align:center">
			<div style="text-align: center">
				<dl class="splash">
					<dt><img src="img/splash.gif" border="0" usemap="#map1" alt="Splash image" /></dt>
					<dd><span>version {{APP_VERSION}}</span></dd>
				</dl>
			</div>
			<map name="map1" id="map1"><area shape="rect" coords="130,78,248,90" href="{{PROJECT_SITEURL}}" alt="Project website" />
			</map>
			{{MESSAGE}}
			{{FORM}}
			</td>
		</tr>
	</table>
</div>
</body></html>
