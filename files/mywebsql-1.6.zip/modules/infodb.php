<?php

	/*************************************************
	*	infoserver.php - Author: Samnan ur Rehman     *
	*	This file is a part of MyWebSQL package       *
	*	PHP5 compatible                               *
	*************************************************/

	function processRequest(&$db)
	{
		if (getDbName() == '')
		{
			echo view('invalid_request');
			return;
		}
		
		if ($db->query("show table status where Engine is not null"))
		{
			createSimpleGrid($db, 'Summary stats for database ['.htmlspecialchars(getDbName()).']');
		}
	}
	
?>