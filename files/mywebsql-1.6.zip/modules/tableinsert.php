<?php

	/********************************************************************
	*	tableinsert.php - Author: Samnan ur Rehman						*
	*	This file is a part of MyWebSQL package							*
	*	PHP5 compatible													*
	*********************************************************************/

	function processRequest(&$db)
	{
		/*Session::del('select', 'result');
		Session::del('select', 'pkey');
		Session::del('select', 'ukey');
		Session::del('select', 'mkey');
		Session::del('select', 'unique_table');
		
		Session::set('select', 'result', array());
		*/

		$tbl = $_REQUEST["name"];

		$sql = "show full fields from `$tbl`";
		//Session::set('select', 'query', $sql);
		if (!$db->query($sql))
			createErrorGrid($db, $sql);
		else
		{
			$str = "insert into `".$tbl."` (";
			$num = $db->numRows();
			$row = $db->fetchRow();
			$str .= "`" . $row[0] . "`";

			if ($row["Extra"] == "auto_increment")
				$str2 = " values (NULL";
			else
				$str2 = " values (\"\"";

			for($i=1; $i<$num; $i++)
			{
				$row = $db->fetchRow();
				$str .= ",`" . $row[0] . "`";
				if ($row["Extra"] == "auto_increment")
					$str2 .= ",NULL";
				//else if (strpos($row["Type"], "int") !== false)
				//	$str2 .= ", ";		// for numeric fields
				else
					$str2 .= ",\"\"";
			}

			$str .= ")";
			$str2 .= ")";

			print "<div name='results' id='results'>".htmlspecialchars($str.$str2)."</div>";
			print "<script type=\"text/javascript\" language='javascript'> parent.transferQuery(); </script>\n";
		}
	}
?>