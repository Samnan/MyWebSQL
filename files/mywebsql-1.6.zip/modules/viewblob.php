<?php

	/*********************************************
	*	viewblob.php - Author: Samnan ur Rehman   *
	*	This file is a part of MyWebSQL package   *
	*	PHP5 compatible                           *
	*********************************************/

	function processRequest(&$db)
	{
		// this function is optimizable ..
		// by reducing the number of queries and the actual query that brings blob data, db server will be happier
		traceMessage("viewBlob...");

		// vrify that the blob data is from the existing and valid query
		$queryCode = v($_REQUEST['query']);
		if ( Session::get('select', 'query') == "" || md5(Session::get('select', 'query')) != $queryCode)
		{
			echo view('invalid_request');
			return;
		}

		$query = Session::get('select', 'query');
		$id = v($_REQUEST["id"]);
		$name = v($_REQUEST["name"]);
		$blobOptions = '';
		$blobData = '';
		$message = Session::get('select', 'unique_table') != "" ? '' : 'Blob data is not editable';  // shows if blob was saved or not

		/*if ( Session::get('select', 'table') != "" && v($_REQUEST['act']) == 'save' && isset($_POST['blobdata']) )
		{
			$saved = saveBlobData($db, $id, $name, $_POST['blobdata']);
			$message = $saved ? 'Blob data saved' : 'Failed to save blob data';
		}*/

		include("config/blobs.php");
		$bType =  ( array_key_exists(v($_REQUEST["blobtype"]), $blobTypes) ) ? v($_REQUEST["blobtype"]) : "txt";

		// @todo: optimize. this should always fetch one row
		if (Session::get('select', 'unique_table') == "")
			$applyLimit = true;
		else
			$applyLimit = strpos($query, "limit ");

		if ($applyLimit == false)
			$query .= " limit $id, 1";

		if (!$db->query($query) || $db->numRows() == 0)
		{
			echo view('error_page');
			return;
		}

		$row = ($applyLimit==false ? $db->fetchRow() : $db->fetchSpecificRow($id));

		// show as image etc ...
		if ($bType && v($_REQUEST["show"]) && $blobTypes[$bType][2])
		{
			ob_end_clean();
			function_exists('ob_gzhandler') ? ob_start("ob_gzhandler") : ob_start();
			header($blobTypes[$bType][2]);
			print $row[$name];
			return true;
		}

		foreach($blobTypes as $k=>$v)
		{
			if ($bType == $k)
				$blobOptions .= "<option value='$k' selected=\"selected\">$v[0]</option>\n";
			else
				$blobOptions .= "<option value='$k'>$v[0]</option>\n";
		}

		// try to show the blob data as specified type
		if ($bType && $blobTypes[$bType] && v($blobTypes[$bType][3]))
		{
			if (strpos($blobTypes[$bType][3], "#link#") !== false)
				$blobData = str_replace("#link#", "?q=wrkfrm&type=viewblob&show=1&id=$id&name=$name&blobtype=$bType&query=".urlencode($queryCode), $blobTypes[$bType][3]);
			//else if (strpos($blobTypes[$bType][3], "#src#") !== false)
			//	print str_replace("#src", $row[$name], $blobTypes[$bType][3]);
			else
				$blobData = htmlspecialchars($row[$name]);
		}
		else if ($bType && $blobTypes[$bType] && v($blobTypes[$bType][4]))
		{
			$func = $blobTypes[$bType][4];
			$blobData = htmlspecialchars(print_r($func($row[$name]), 1));
		}
		else
			$blobData = htmlspecialchars($row[$name]);

		$toolbar = (Session::get('select', 'unique_table') != "") ? view('viewblob_toolbar', array('MESSAGE' => $message)) : $message;

		$replace = array('ID' => $id,
								'NAME' => $name,
								'BLOBOPTIONS' => $blobOptions,
								'BLOBDATA' => $blobData,
								'TABLE' => Session::get('select', 'unique_table') == "" ? "" : htmlspecialchars(Session::get('select', 'unique_table')),
								'QCODE' => md5(Session::get('select', 'query')),  // this will help identify that the blob data belongs to this query
								'BLOB_TOOLBAR' => $toolbar
							);
		echo view('viewblob', $replace);
	}
	
	function saveBlobData(&$db, $id, $field, $data)
	{
		traceMessage("saving blob data...$id, $field, $data");
		return true;
	}

?>