<?php

	/********************************************************************
	*	usermanager.php - Author: Samnan ur Rehman						*
	*	This file is a part of MyWebSQL package							*
	*	user and permissions management library							*
	*	PHP5 compatible													*
	*********************************************************************/

if (!defined("CLASS_USERMANAGER_INCLUDED")) 
{ 
	define("CLASS_USERMANAGER_INCLUDED", "1");
	
class UserManager
{
	var $db;
	var $userTable;
	var $dbTable;
	
	function UserManager(&$db)
	{
		$this->db = $db;
		$this->userTable = '`mysql`.`user`';
		$this->dbTable = '`mysql`.`db`';
	}

	function getUserList()
	{
		$sql = 'select * from '.$this->userTable.' order by `User`';
		if (!$db->query($sql))
			return array();
		$userList = array();
		while($row = db->fetchRow())
		{
			$userName = $row['User'].'@'.$row['Host'];
			$userList[$userName] = $row;
		}
		
		return $userList;
	}
	
	function getUserPermissions($userName)
	{
	}
}

}
?>