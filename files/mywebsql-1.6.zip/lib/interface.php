﻿<?php

	/***********************************************
	*	interface.php - Author: Samnan ur Rehman    *
	*	This file is a part of MyWebSQL package     *
	*	Contains functions for rendering the GUI    *
	*	PHP5 compatible                             *
	************************************************/

	function createMenuBar()
	{
		$theme_menu = '';
		include ("config/themes.php");
			foreach($THEMES as $theme_id => $theme)
					$theme_menu .= '<li><a href="javascript:interfaceTheme(\''.$theme_id.'\')">'.$theme.'</a></li>';
		$replace = array('THEMES_MENU' => $theme_menu);
		echo view('menubar', $replace);
	}

	function createDatabaseTree(&$db, $dblist)
	{
		global $HTML;
		if (getDbName())
		{
			print '<ul id="tablelist" class="filetree">';
			$tables = $db->getTables();
			print '<li><span class="tablef">Tables ('.count($tables).')</span>';
			if (count($tables) > 0)
			{
				foreach($tables as $key=>$table)
				{
					$tables[$key] = $id = html::id($table);
                    $table = htmlspecialchars($table);
					print '<ul><li><span class="file otable" id="t_'.$id.'"><a href=\'javascript:objDefault("table", "'.$table.'")\'>'.$table.'</a></span></li></ul>';
				}
			}
			print "</li>\n";

			if (Session::get('db', 'version') >= 5)
			{
				$tables = $db->getViews();
				print '<li><span class="viewf">Views ('.count($tables).')</span>';
				if (count($tables) > 0)
				{
					foreach($tables as $key=>$table)
					{
						$tables[$key] = $id = html::id($table);
						$table = htmlspecialchars($table);
						print '<ul><li><span class="file oview" id="t_'.$id.'"><a href=\'javascript:objDefault("view", "'.$id.'")\'>'.$table.'</a></span></li></ul>';
					}
				}
				print "</li>\n";

				$tables = $db->getProcedures();
				print '<li><span class="procf">Procedures ('.count($tables).')</span>';
				if (count($tables) > 0)
				{
					foreach($tables as $key=>$table)
					{
						$tables[$key] = $id = html::id($table);
						$table = htmlspecialchars($table);
						print '<ul><li><span class="file oproc" id="t_'.$id.'"><a href=\'javascript:objDefault("procedure", "'.$id.'")\'>'.$table.'</a></span></li></ul>';
					}
				}
				print "</li>\n";

				$tables = $db->getFunctions();
				print '<li><span class="funcf">Functions ('.count($tables).')</span>';
				if (count($tables) > 0)
				{
					foreach($tables as $key=>$table)
					{
						$tables[$key] = $id = html::id($table);
						$table = htmlspecialchars($table);
						print '<ul><li><span class="file ofunc" id="t_'.$id.'"><a href=\'javascript:objDefault("function", "'.$id.'")\'>'.$table.'</a></span></li></ul>';
					}
				}
				print "</li>\n";

				$tables = $db->getTriggers();
				print '<li><span class="trigf">Triggers ('.count($tables).')</span>';
				if (count($tables) > 0)
				{
					foreach($tables as $key=>$table)
					{
						$tables[$key] = $id = html::id($table);
						$table = htmlspecialchars($table);
						print '<ul><li><span class="file otrig" id="t_'.$id.'"><a href=\'javascript:objDefault("trigger", "'.$id.'")\'>'.$table.'</a></span></li></ul>';
					}
				}
				print "</li>\n";
				print '</ul>';
			}
		}
		else
		{
			print '<ul id="tablelist" class="dblist">';
			foreach($dblist as $dbname)
				print '<li><span class="odb"><a href="javascript:dbSelect(\''.$dbname.'\')">'.htmlspecialchars($dbname).'</a></span>';
			print '</ul>';
		}
	}

	function createContextMenus()
	{
		echo view('menuobjects');
	}

	function getSqlEditorType()
	{
		return (SQL_EDITORTYPE == "codemirror") ? 1 : 0;
	}

	function updateSqlEditor()
	{
		if (SQL_EDITORTYPE == "codemirror")
		{
			$min = file_exists('js/min/minify.txt');
			$js = $min ? 'codemirror' : 'editor/codemirror';
			print '<link rel="stylesheet" type="text/css" href="cache.php?css=mysqlcolors" />';
			print "<script type=\"text/javascript\" language=\"javascript\" src=\"cache.php?script=$js\"></script><script type=\"text/javascript\" language=\"javascript\">
				$(function() {\n";

			sqlEditorJs($min, 'commandEditor', 'sqlEditFrame', 'initStart();');
			sqlEditorJs($min, 'commandEditor2', 'sqlEditFrame2');
			sqlEditorJs($min, 'commandEditor3', 'sqlEditFrame3');
			print '}); </script>';
		}
	}

	function sqlEditorJs($min, $id, $frameId, $init='')
	{
		if ($min)
			print $id.' = CodeMirror.fromTextArea("'.$id.'", { basefiles: ["js/min/codemirror_base.js"],';
		else
			print $id.' = CodeMirror.fromTextArea("'.$id.'", { parserfile: "mysql.js", path: "js/editor/",';

		print 'iframeId: "'.$frameId.'", iframeClass: "sqlEditFrame",
				height: "100%", tabMode : "default", stylesheet: "cache.php?css=mysqlcolors",
				lineNumbers: true, tabFunction : function() { document.getElementById("nav_query").focus(); },
				onLoad : function() { '.$init.' }
				});';
	}

	function setupHotkeys()
	{
		if (!defined('HOTKEYS_ENABLED') || !HOTKEYS_ENABLED)
			return false;

		print "<script type=\"text/javascript\" language=\"javascript\" src=\"cache.php?script=hotkeys\"></script><script type=\"text/javascript\" language=\"javascript\"> $(function() {\n";
		include ("config/keys.php");
		foreach ($DOCUMENT_KEYS as $name => $func)
		{
			$code = $KEY_CODES[$name][0];
			print "$(document).bind('keydown', '$code', function (evt) { $func; return false; });\n";
		}
		foreach ($EDITOR_KEYS as $name => $func)
		{
			$code = $KEY_CODES[$name][0];
			//print "$(document.getElementById('sqlEditFrame').contentWindow.document).bind('keydown', '$code', function (evt) { $func; return false; });\n";
			print "editorHotkey('$code', function (evt) { $func; return false; } );\n";
		}
		print " }); </script>";
		return true;
	}
?>