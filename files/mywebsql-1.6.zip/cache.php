<?php

	/*****************************************************
	*  cache.php - Author: Samnan ur Rehman              *
	*  This file is a part of MyWebSQL package           *
	*  outputs scripts and stylesheet for application    *
	*  PHP5 compatible                                   *
	******************************************************/

	include("config/themes.php");
	include("config/config.php");
	include("lib/functions.php");

	function_exists('ob_gzhandler') ? ob_start("ob_gzhandler") : ob_start();
	ob_implicit_flush(0);
	$regex = '#^(\w+/){0,2}\w+$#';

	if (v($_REQUEST["script"]) != "")
	{
		// use minified or raw js?
		$script_path = file_exists('js/min/minify.txt') ? "js/min" : "js";
		$scripts = explode(",", $_REQUEST["script"]);
		header("mime-type: text/javascript");
		header("content-type: text/javascript");
		echo "/* MyWebSql script file */\n\n";
		foreach($scripts as $script)
			if ( preg_match($regex, $script) == 1 )
				if(file_exists("$script_path/$script".".js"))
					echo file_get_contents("$script_path/$script".".js") . "\n\n";
	}
	else if (v($_REQUEST["css"]) != "")
	{
		$styles = explode(",", $_REQUEST["css"]);
		header("mime-type: text/css");
		header("content-type: text/css");
		echo "/* MyWebSql style sheet */\n\n";
		foreach($styles as $css)
			if ( preg_match($regex, $css) == 1 )
				if(file_exists("themes/".THEME_PATH."/$css".".css"))
					echo file_get_contents("themes/".THEME_PATH."/$css".".css") . "\n\n";
	}

	print_gzipped_output();
?>