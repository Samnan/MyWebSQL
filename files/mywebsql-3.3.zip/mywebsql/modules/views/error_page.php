<link href="cache.php?css=theme,default" rel="stylesheet" />
<script type="text/javascript" language='javascript' src="cache.php?script=common,jquery"></script>
<div name="results" id="results">
	<table cellspacing="5" width="100%" height="100%" border="0">
		<tr><td>
		<div class='message ui-state-error'><?php echo __('The requested page is not available on the server'); ?></div>
		</td></tr>
	</table>
</div>
<script type="text/javascript" language="javascript">
	window.title = "<?php echo __('Error'); ?> !";
	$( function() { $("#popup_overlay").remove(); } );
</script>