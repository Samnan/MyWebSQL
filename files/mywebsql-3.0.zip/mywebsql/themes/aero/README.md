MyWebSQL-Theme-aero
===================

An experimental glassy theme for the MyWebSQL interface