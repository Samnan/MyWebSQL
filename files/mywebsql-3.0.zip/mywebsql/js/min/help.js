/*
    http://mywebsql.net/license
*/
function showHelpPage(a){window.location.href="?q=wrkfrm&type=help&p="+a};
