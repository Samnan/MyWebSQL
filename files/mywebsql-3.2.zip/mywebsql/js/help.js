/**
 * This file is a part of MyWebSQL package
 *
 * @file:      js/help.js
 * @author     Samnan ur Rehman
 * @copyright  (c) 2008-2012 Samnan ur Rehman
 * @web        http://mywebsql.net
 * @license    http://mywebsql.net/license
 */

function showHelpPage(x) {
	window.location.href = "?q=wrkfrm&type=help&p=" + x;
}