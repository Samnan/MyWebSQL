<?php

	/****************************************************************
	 *  auth.php                                                    *
	 *  defines authentication mechanism for the application        *
	 *  Notes:                                                      *
	 *    Changing this file manually might break the application   *
	 *    or create security issues.                                *
	 *  Please edit only if you know what you are doing !!!         *
	 ****************************************************************/

	// AUTH_TYPE defines the login/startup behaviour of the application
    // NONE		= No userid/password is asked for (NOT recommended)
    // BASIC	= browser requests authentication dialog
    // LOGIN	= User enters userid and password manually
	define('AUTH_TYPE', 'LOGIN');

	// AUTH_SERVER defines the name of mysql server for connections and authenticating users
	define('AUTH_SERVER', 'localhost');

	// if AUTH_TYPE is NONE, then use the following userid and password to connect to mysql server
	// these are not used if AUTH_TYPE is BASIC or LOGIN
	define('AUTH_LOGIN', 'test');
	define('AUTH_PASSWORD', 'test');


	// ACCESS_TYPE defines what can the user access after logging in to the system
	// DEFAULT = authenticated server connection is used.
	// LIST = list of preconfigured connections are shown at startup
	define('ACCESS_TYPE', 'DEFAULT');

?>