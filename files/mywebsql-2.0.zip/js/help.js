function showHelpPage(x) {
	window.location.href = "?q=wrkfrm&type=help&p=" + x;
}