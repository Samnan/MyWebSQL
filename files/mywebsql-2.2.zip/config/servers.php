<?php

	/************************************************************************
	 *  servers.php                                                         *
	 *  server configuration file                                           *
	 *  defining more that one server here will give user the option to     *
	 *     select a server at login time                                    *
	 *  Notes:                                                              *
	 *   server list is used only when authentication type is LOGIN         *
	 ************************************************************************/

	// add or remove list of servers below
	// if there are more than one servers defined, the user will be given choice
	// at the time of login to select a server

	$SERVER_LIST = array(
		'Localhost'				=> 'localhost',
		//'Test Server'		=> 'localhost:8456',
		//'Test Server 2'		=> 'test-server-2',
	);
?>