<link href="cache.php?css=default" rel="stylesheet" />
<div name="results" id="results">
	<table cellspacing="5" width="100%" height="100%" border="0">
		<tr><td>
		<div class='warning'><?php echo __('The requested page is not available on the server'); ?></div>
		</td></tr>
	</table>
</div>
<script type="text/javascript" language="javascript">
	msg = <?php echo __('Error'); ?>' !';
	if (window.parent)
		parent.updatePopupTitle(msg);
	else
		updatePopupTitle(msg);
</script>