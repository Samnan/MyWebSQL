	<div class="heading">Miscellaneous</div>
		<ul>
			<li>Queries are modified slightly on server to return <i>only first <b>100</b> records</i>, which is sufficient enough for a daily basis developer work.<br/>(<b>This can be changed by modifying configuration file</b>)</li>
			<li>To submit bug reports or feature requests, use the links provided in the Help menu inside the application.</li>
			<li>If you believe any graphics/libraries used in this application violate license terms, Please report back the issue as soon as possible so it can be rectified.</li>
		</ul>
		</ul>
	</div>