<?php
/**
 * This file is a part of MyWebSQL package
 *
 * @file:      modules/views/pgsql/templates/datatypes.php
 * @author     Samnan ur Rehman
 * @copyright  (c) 2008-2012 Samnan ur Rehman
 * @web        http://mywebsql.net
 * @license    http://mywebsql.net/license
 */

 /*
		 bigint => int8
		 bigserial => int8
		 bit => bit
		 bit varying => varbit
		 boolean => bool
		 box => box
		 bytea => bytea
		 character varying => varchar
		 character => bpchar
		 cidr => cidr
		 circle => circle
		 date => date
		 double precision => float8
		 inet => inet
		 integer => int4
		 interval => interval
		 line => line
		 lseg => lseg
		 macaddr => macaddr
		 money => money
		 numeric => numeric
		 path => path
		 point => point
		 polygon => polygon
		 real => float4
		 smallint => int2
		 serial => int4
		 text => text
		 time => time
		 time with time zone => timetz
		 timestamp => timestamp
		 timestamp with time zone => timestamptz
 */
?>
