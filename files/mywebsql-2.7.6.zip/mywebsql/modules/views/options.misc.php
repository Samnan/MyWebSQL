<strong>
    <table border="0" cellpadding="5" cellspacing="0" style="width: 100%">
		<tr>
            <td colspan="2" class='title'>
                <strong>Miscellaneous</strong></td>
        </tr>
        <tr>
            <td valign="top">
				Work in progress here ...
            </td>
		</tr>
    </table>
	<br />
</strong>
