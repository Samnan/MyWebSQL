<?php

	/***********************************************
	*  copy.php - Author: Samnan ur Rehman         *
	*  This file is a part of MyWebSQL package     *
	*  PHP5 compatible                             *
	***********************************************/

	function processRequest(&$db) {
		$type = v($_REQUEST["id"]);
		$name = v($_REQUEST["name"]);
		$new_name = v($_REQUEST["query"]);
		
		if (!$name || !$new_name ) {
			createErrorGrid($db, '');
			return;
		}
		
		$query = '';
		$success = false;
		
		if($type == 'table') {
			$query = 'create '.$db->escape($type).' `' . $db->escape($new_name) . '` like `' . $db->escape($name) . '`';
			$success = $db->query($query);
			if ($success) {
				$query = 'insert into `' . $db->escape($new_name) . '` select * from `' . $db->escape($name) . '`';
				$success = $db->query($query);
			}
		}
		else {
			$command = $db->getCreateCommand($type, $name);
			$search = '/(create.*'.$type. ' )('.$name.'|\`'.$name.'\`)/i';
			$replace = '${1} `'.$new_name.'`';
			$query = preg_replace($search, $replace, $command, 1);
			$success = $db->query($query);
		}
		
		if ($success) {
			Session::set('db', 'altered', true);
			createInfoGrid($db, '', 2);
		}
		else
			createErrorGrid($db, $query);
	}
?>