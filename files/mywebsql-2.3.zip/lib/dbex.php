<?php

	/******************************************************************
	*	dbex.php - Author: Samnan ur Rehman                            *
	*	This file is a part of MyWebSQL package                        *
	*	A very simple to use and easy to debug mysqli wrapper class    *
	*	Functions identical to DbManager class using mysql* functions  *
	*	PHP5 compatible                                                *
	******************************************************************/

if (defined("CLASS_DB_INCLUDED"))
	return true;

define("CLASS_DB_INCLUDED", "1");

define("NOT_NULL_FLAG",         1);         /* Field can't be NULL */
define("PRI_KEY_FLAG",           2);         /* Field is part of a primary key */
define("UNIQUE_KEY_FLAG",        4);         /* Field is part of a unique key */
define("MULTIPLE_KEY_FLAG",      8);         /* Field is part of a key */
define("BLOB_FLAG",            16);         /* Field is a blob */
define("UNSIGNED_FLAG",         32);         /* Field is unsigned */
define("ZEROFILL_FLAG",         64);        /* Field is zerofill */
define("BINARY_FLAG",          128);         /* Field is binary   */
define("ENUM_FLAG",            256);         /* field is an enum */
define("AUTO_INCREMENT_FLAG",  512);         /* field is a autoincrement field */
define("TIMESTAMP_FLAG",      1024);         /* Field is a timestamp */ 
define("SET_FLAG",            2048);         /* Field is a set */ 

class DbManager {
	var $ip, $user, $password, $db;
	var $conn;
	var $result;		// array
	var $errMsg;
	var $escapeData;
	var $queryTime;

	function DbManager() {
		$this->conn = null;
		$this->errMsg = null;
		$this->escapeData = true;
		$this->result = array();
	}

	function connect($ip, $user, $password, $db="")	{
		$this->conn = @mysqli_connect($ip, $user, $password);
		if (!$this->conn)
			return $this->error(mysql_error());
		
		if ($db && !@mysqli_select_db($this->conn, $db))
			return $this->error(mysqli_error($this->conn));
		
		$this->ip = $ip;
		$this->user = $user;
		$this->password = $password;
		$this->db = $db;
		
		$this->selectVersion();
		$this->query("SET CHARACTER SET 'utf8'");
		$this->query("SET collation_connection = 'utf8_general_ci'");
		
		return true;
	}

	function pconnect($ip, $user, $password, $db) {
		log_message("db: pconnecting $ip, $user, $db");
		$this->conn = @mysqli_connect($ip, $user, $password);
		if (!$this->conn)
			return $this->error(mysql_error());
			
		if ($db && !@mysqli_select_db($this->con, $db))
			return $this->error(mysqli_error($this->conn));
		$this->ip = $ip;
		$this->user = $user;
		$this->password = $password;
		$this->db = $db;
		
		$this->selectVersion();
		
		return true;
	}
	
	function disconnect() {
		@mysqli_close($this->conn);
		$this->conn = false;
		return true;
	}
	
	function selectDb($db) {
		$this->db = $db;
		mysqli_select_db($this->conn, $this->db);
	}
	
	function query($sql, $stack=0) {		// call with query($sql, 1) to store multiple results
		if (!$this->conn) {
			log_message("DB: Connection has been closed");
			return false;
		}
	
		if (v($this->result[$stack]))
			@mysqli_free_result($this->result[$stack]);

		$this->result[$stack] = "";
		
		//traceMessage("Query: $sql");
		$this->queryTime = $this->getMicroTime();
		$this->result[$stack] = @mysqli_query($this->conn, $sql);
		$this->queryTime = $this->getMicroTime() - $this->queryTime;
		
		if ($this->result[$stack] === FALSE) {
			$this->errMsg = mysqli_error($this->conn);
			log_message("DB: $sql ::: ".@mysqli_error($this->conn));
			return false;
		}
		
		return true;
	}

	function getWarnings() {
		$ret = array();
		$res = mysqli_query($this->conn, "SHOW WARNINGS");
		if ($res !== FALSE) {
			while($row = mysqli_fetch_array($res))
				$ret[$row['Code']] = $row['Message'];
		}
		return $ret;
	}
	
	function getQueryTime($time=false) {  // returns formatted given value or internal query time
		return sprintf("%.2f", ($time ? $time : $this->queryTime) * 1000) . " ms";
	}
	
	function hasAffectedRows() {
		return ($this->getAffectedRows() > 0);
	}
	
	function insert($table, $values) {
		if (!is_array($values))
			return false;
		
		$sql = "insert into $table (";
		
		foreach($values as $field=>$value)
			$sql .= " $field,";
		
		$sql = substr($sql, 0, strlen($sql) - 1);
		
		$sql .= ") values (";
		
		foreach($values as $field=>$value) {
			if ($this->escapeData)
				$sql .= "'" . $this->escape($value) . "',";
			else
				$sql .= "'$value',";
		}
		
		$sql = substr($sql, 0, strlen($sql) - 1);
		
		$sql .= ")";
		
		$this->query($sql);
	}
	
	function update($table, $values, $condition="") {
		if (!is_array($values))
			return false;
		
		$sql = "update $table set ";
		
		foreach($values as $field=>$value) {
			if ($this->escapeData)
				$sql .= "$field = '" . $this->escape($field) . "',";
			else
				$sql .= "$field = '$value',";
		}
		
		$sql = substr($sql, 0, strlen($sql) - 1);
		
		if ($condition != "")
			$sql .= "$condition";
		
		$this->query($sql);
	}
	
	function getInsertID() {
		return mysqli_insert_id($this->conn);
	}
	
	function getResult($stack=0) {
		return $this->result[$stack];
	}
	
	function hasResult($stack=0) {
		return (is_object($this->result[$stack]));	// !== FALSE && $this->result[$stack] !== TRUE);
	}
	
	function fetchRow($stack=0, $type="") {
		if($type == "")
			$type = MYSQLI_BOTH;
		
		if (!$this->result[$stack]) {
			log_message("DB: called fetchRow[$stack] but result is false");
			return;
		}
		return @mysqli_fetch_array($this->result[$stack], $type);
	}
	
	function fetchSpecificRow($num, $type="", $stack=0) {
		if($type == "")
			$type = MYSQL_BOTH;
		
		if (!$this->result[$stack]) {
			log_message("DB: called fetchSpecificRow[$stack] but result is false");
			return;
		}
		
		mysqli_data_seek($this->result[$stack], $num);
		return @mysqli_fetch_array($this->result[$stack], $type);
	}
	
	function numRows($stack=0) {
		return mysqli_num_rows($this->result[$stack]);
	}
	
	function error($str) {
		log_message("DB: " . $str);
		$this->errMsg = $str;
		return false;
	}
	
	function getError() {
		return $this->errMsg;
	}
	
	function escape($str) {
		return mysqli_escape_string($this->conn, $str);
	}
	
	function setEscape($escape=true) {
		$this->escapeData = $escape;
	}

	function getAffectedRows() {
		return mysqli_affected_rows($this->conn);
	}
	
	/**************************************/
	function getDatabases() {
		$res = mysqli_query($this->conn, "show databases");
		$ret = array();
		while($row = mysqli_fetch_array($res))
			$ret[] = $row[0];
		return $ret;
	}
	
	function getTables() {
		if (!$this->db)
			return array();
		$res = mysqli_query($this->conn, "show table status from `$this->db` where engine is NOT null");
		//$res = mysql_query("show tables", $this->conn);
		$ret = array();
		while($row = mysqli_fetch_array($res))
			$ret[] = $row[0];
		return $ret;
	}
	
	function getViews() {
		if (!$this->db)
			return array();
		$res = mysqli_query($this->conn, "show table status from `$this->db` where engine is null");
		$ret = array();
		while($row = mysqli_fetch_array($res))
			$ret[] = $row[0];
		return $ret;
	}
	
	function getProcedures() {
		if (!$this->db)
			return array();
		$res = mysqli_query($this->conn, "show procedure status where db = '$this->db'");
		$ret = array();
		while($row = mysqli_fetch_array($res))
			$ret[] = $row[1];
		return $ret;
	}
	
	function getFunctions() {
		if (!$this->db)
			return array();
		$res = mysqli_query($this->conn, "show function status where db = '$this->db'");
		$ret = array();
		while($row = mysqli_fetch_array($res))
			$ret[] = $row[1];
		return $ret;
	}
	
	function getTriggers() {
		if (!$this->db)
			return array();
		$res = mysqli_query($this->conn, "select `TRIGGER_NAME` from `INFORMATION_SCHEMA`.`TRIGGERS` where `TRIGGER_SCHEMA` = '$this->db'");
		$ret = array();
		while($row = mysqli_fetch_array($res))
			$ret[] = $row[0];
		return $ret;
	}
	
	function getEvents() {
		if (!$this->db)
			return array();
		$res = mysqli_query($this->conn, "select `EVENT_NAME` from `INFORMATION_SCHEMA`.`EVENTS` where `EVENT_SCHEMA` = '$this->db'");
		$ret = array();
		while($row = mysqli_fetch_array($res))
			$ret[] = $row[0];
		return $ret;
	}
	
	/**************************************/
	function getFieldInfo($stack=0) {
		$fields = array();
		$i = 0;
		while ($i < mysqli_num_fields($this->result[$stack])) {
			$meta = mysqli_fetch_field_direct($this->result[$stack], $i);
			if ($meta) {
				$f = new StdClass;
				$f->name = $meta->name;
				$f->table = $meta->table;
				$f->not_null = ($meta->flags & NOT_NULL_FLAG) ? 1 : 0;
				$f->blob = ($meta->flags & BLOB_FLAG) ? 1 : 0;
				$f->pkey = ($meta->flags & PRI_KEY_FLAG) ? 1 : 0;
				$f->ukey = ($meta->flags & UNIQUE_KEY_FLAG) ? 1 : 0;
				$f->mkey = ($meta->flags & MULTIPLE_KEY_FLAG) ? 1 : 0;
				$f->zerofill = ($meta->flags & ZEROFILL_FLAG) ? 1 : 0;
				$f->unsigned = ($meta->flags & UNSIGNED_FLAG) ? 1 : 0;
				$f->autoinc = ($meta->flags & AUTO_INCREMENT_FLAG) ? 1 : 0;
				$f->numeric = $meta->type < 10 ? 1 : 0;
				if ($meta->flags & ENUM_FLAG)
					$f->type = 'enum';
				else if ($meta->flags & SET_FLAG)
					$f->type = 'set';
				else if ($meta->flags & BINARY_FLAG)
					$f->type = 'binary';
				else if ($meta->type < 10)
					$f->type = 'numeric';
				else
					$f->type = 'char';
				if ($f->type == 'enum' || $f->type == 'set')
					$f->list = $this->getFieldValues($f->table, $f->name);
				$fields[] = $f;
			}
			$i++;
		}
		return $fields;
	}
	
	function getMicroTime() {
	   list($usec, $sec) = explode(" ",microtime());
	   return ((float)$usec + (float)$sec);
	}
	
	function selectVersion() {
		$res = mysqli_query($this->conn, "SHOW VARIABLES LIKE 'version%'");
		while($row = mysqli_fetch_array($res)) {
			if ($row[0] == 'version') {
				Session::set('db', 'version', intval($row[1]));
				Session::set('db', 'version_full', $row[1]);
			} else if ($row[0] == 'version_comment') {
				Session::set('db', 'version_comment', $row[1]);
			}
		}
	}
	
	function getCreateCommand($type, $name) {
		$cmd = '';
		$type = $this->escape($type);
		$name = $this->escape($name);
		
		if ($type == "trigger")
			$sql = "show triggers where `trigger` = '$name'";
		else
			$sql = "show create $type `$name`";

		if (!$this->query($sql) || $this->numRows() == 0)
			return '';
		
		$row = $this->fetchRow();
		
		if ($type == "trigger")
			$cmd = "create trigger `$row[0]`\r\n$row[4] $row[1] on `$row[2]`\r\nfor each row\r\n$row[3]";
		else {
			switch($type) {
				case 'table':
				case 'view':
					$cmd = $row[1];
					break;
				case 'procedure':
				case 'function':
					$cmd = $row[2];
					break;
				case 'event':
					$cmd = $row[3];
					break;
			}
		}
		return $cmd;
	}
	
	function getFieldValues($table, $name) {
		$sql = 'show full fields from `'.$table.'` where `Field` = \''.$this->escape($name).'\'';
		$res = mysqli_query($this->conn, $sql);
		if (mysqli_num_rows($res) == 0)
			return ( (object) array('list' => array()) );
		$row = mysqli_fetch_array($res);
		$type = $row['Type'];
		preg_match('/enum\((.*)\)$/', $type, $matches);
		if (!isset($matches[1]))
			preg_match('/set\((.*)\)$/', $type, $matches);
		if (isset($matches[1])) {
			$list = explode(',', $matches[1]);
			foreach($list as $k => $v)
				$list[$k] = str_replace("\\'", "'", trim($v, " '"));
			return $list;
		}
		return ( (object) array('list' => array()) );
	}
	
	function getEngines() {
		$sql = 'show engines';
		$res = mysqli_query($this->conn, $sql);
		if (mysqli_num_rows($res) == 0)
			return ( array() );
		
		$arr = array();
		while($row = mysqli_fetch_array($res))
			if ($row['Support'] != 'NO')
				$arr[] = $row['Engine'];
		return $arr;
	}
	
	function getCharsets() {
		$sql = 'show character set';
		$res = mysqli_query($this->conn, $sql);
		if (mysqli_num_rows($res) == 0)
			return ( array() );
		
		$arr = array();
		while($row = mysqli_fetch_array($res))
			$arr[] = $row['Charset'];

		asort($arr);
		return $arr;
	}
	
	function getCollations() {
		$sql = 'show collation';
		$res = mysqli_query($this->conn, $sql);
		if (mysqli_num_rows($res) == 0)
			return ( array() );
		
		$arr = array();
		while($row = mysqli_fetch_array($res))
			$arr[] = $row['Collation'];

		asort($arr);
		return $arr;
	}
	
	function getTableProperties($table) {
		$sql = "show table status where `Name` like '".$this->escape($table)."'";
		if (!$this->query($sql, "_tmp_query"))
			return FALSE;
		return $this->fetchRow("_tmp_query");
	}
	
	function queryTableStatus() {
		$sql = "show table status where Engine is not null";
		return $this->query($sql);
	}
	
	function flush($option = '', $skiplog=false) {
		$options = array('HOSTS', 'PRIVILEGES', 'TABLES', 'STATUS', 'DES_KEY_FILE', 'QUERY CACHE', 'USER_RESOURCES', 'TABLES WITH READ LOCK');
		if ($option == '') {
			foreach($options as $option) {
				$sql = "flush " . ( $skiplog ? "NO_WRITE_TO_BINLOG " : "") . $this->escape($option);
				$this->query($sql, '_temp_flush');
			}
			$this->query('UNLOCK TABLES', '_temp_flush');
		} else {
			$sql = "flush " . ( $skiplog ? "NO_WRITE_TO_BINLOG " : "") . $this->escape($option);
			$this->query($sql, '_temp_flush');
			if ($option == 'TABLES WITH READ LOCK')
				$this->query('UNLOCK TABLES', '_temp_flush'); 
		}
		
		return true;
	}
}
?>